package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class AccountSetUpPage {
  private User currentUser;
  private UserAccessControl adminController; 
  private Stage mainStage; 

  // Constructor to initialize AccountSetUpPage with required parameters
  public AccountSetUpPage(User currentUser, UserAccessControl adminController, Stage mainStage) {
    this.currentUser = currentUser;
    this.adminController = adminController;
    this.mainStage = mainStage;
  }

  // Method to set up the account setup page
  public Scene setUpPage() {
    mainStage.setTitle("Finish Setting Up Your Account");

    
    GridPane setupGrid = new GridPane();
    setupGrid.setAlignment(Pos.CENTER); 
    setupGrid.setHgap(10); 
    setupGrid.setVgap(10); 
    setupGrid.setPadding(new Insets(25, 25, 25, 25)); 

    // Email input field
    Label emailOne = new Label("Email:");
    TextField emailEnter = new TextField();
    setupGrid.add(emailOne, 0, 0); 
    setupGrid.add(emailEnter, 1, 0);

    // First Name input field
    Label first = new Label("First Name:");
    TextField firstEnter = new TextField();
    setupGrid.add(first, 0, 1);
    setupGrid.add(firstEnter, 1, 1);

    // Middle Name input field
    Label middle = new Label("Middle Name:");
    TextField middleEnter = new TextField();
    setupGrid.add(middle, 0, 2);
    setupGrid.add(middleEnter, 1, 2);

    // Last Name input field
    Label last = new Label("Last Name:");
    TextField lastEnter = new TextField();
    setupGrid.add(last, 0, 3);
    setupGrid.add(lastEnter, 1, 3);

    // Preferred Name input field
    Label preferredNameLabel = new Label("Preferred Name:");
    TextField preferredNameInput = new TextField();
    setupGrid.add(preferredNameLabel, 0, 4);
    setupGrid.add(preferredNameInput, 1, 4);

    // Button to complete account setup
    Button completeSetupButton = new Button("Save");
    setupGrid.add(completeSetupButton, 1, 5); 

    // Action handler for the button when clicked
    completeSetupButton.setOnAction(e -> completed(
      firstEnter.getText(),
      middleEnter.getText(),
      lastEnter.getText(),
      preferredNameInput.getText(),
      emailEnter.getText()
    ));

    // Return the scene with the specified dimensions
    return new Scene(setupGrid, 300, 275);
  }

  // Method called when the user completes the setup
  private void completed(String firstName, String middleName, String lastName,
    String preferredName, String email) {

    // Validate the input fields for correctness
    String correct = inputCorrect(firstName, middleName, lastName, preferredName, email);
    if (!correct.isEmpty()) {
      // Show an error alert if there are validation errors
      Alert alert = new Alert(Alert.AlertType.ERROR, correct);
      alert.showAndWait();
      return; // Exit the method if validation fails
    }

    // Finalize the setup using the admin controller
    boolean succeed = adminController.finalize(currentUser, firstName, middleName, lastName, preferredName, email);

    if (succeed) {
      // Proceed to role selection if setup is successful
      new SelectRolePage(mainStage, adminController).handleRoleSelection(currentUser);
    } else {
      // Show an error alert if the setup fails
      Alert alert = new Alert(Alert.AlertType.ERROR, "Setup failed. Please try again.");
      alert.showAndWait();
    }
  }

  // Method to validate the user input fields
  private String inputCorrect(String firstName, String middleName, String lastName,
    String preferredName, String email) {
    StringBuilder errors = new StringBuilder();

    // Check for empty fields and add error messages
    if (email.isEmpty()) {
      errors.append("Email is empty!\n");
    }
    if (firstName.isEmpty()) {
      errors.append("First name is empty!\n");
    }
    if (lastName.isEmpty()) {
      errors.append("Last name is empty!\n");
    } else if (!isValidEmail(email)) {
      errors.append("Not a valid email!\n");
    }

    // Validate middle and preferred names
    if (!middleName.isEmpty() && !validNameCheck(middleName)) {
      errors.append("Not Valid Middle Name!\n");
    }
    if (!preferredName.isEmpty() && !validNameCheck(preferredName)) {
      errors.append("Preferred name invalid!\n");
    }

    return errors.toString(); // Return any errors found
  }

  // Helper method to check if a name is valid (only letters and spaces)
  private boolean validNameCheck(String name) {
    return name.matches("[a-zA-Z\\s]+");
  }

  // Helper method to check if an email is valid
  private boolean isValidEmail(String email) {
    return email != null && email.contains("@") && email.contains(".") && email.indexOf("@") < email.lastIndexOf(".");
  }
}
