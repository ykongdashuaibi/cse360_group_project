package application;

import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.util.HashSet;
import java.util.Set;

public class InvitePage {
  // User access control for managing users
  private UserAccessControl UserAdminController;
  // Main stage for displaying scenes
  private Stage mainStage;

  // Constructor initializing UserAdminController and mainStage
  public InvitePage(UserAccessControl UserAdminController, Stage mainStage) {
    this.UserAdminController = UserAdminController;
    this.mainStage = mainStage;
  }

  // Method to create the admin invitation page scene
  public Scene adminPageCreate() {
    GridPane adminGrid = new GridPane();
    adminGrid.setVgap(10);
    adminGrid.setHgap(10);
    adminGrid.setPrefSize(300, 300); 

    // Create labels and input fields for username and email
    Label username = new Label("Username:");
    TextField userNameEnter = new TextField();
    Label email = new Label("Email:");
    TextField emailEnter = new TextField();
    Label role = new Label("Choose Roles");

    // Create checkboxes for role selection
    CheckBox adminRoleCheckBox = new CheckBox("ADMIN");
    CheckBox studentRoleCheckBox = new CheckBox("STUDENT");
    CheckBox instructorRoleCheckBox = new CheckBox("INSTRUCTOR");

    // Create buttons for inviting and going back
    Button inviteButton = new Button("Invite");
    Button backButton = new Button("<-- Back");

    // Add components to the grid
    adminGrid.add(username, 0, 0);
    adminGrid.add(userNameEnter, 1, 0);
    adminGrid.add(email, 0, 1);
    adminGrid.add(emailEnter, 1, 1);
    adminGrid.add(role, 0, 2);
    adminGrid.add(adminRoleCheckBox, 1, 2);
    adminGrid.add(studentRoleCheckBox, 1, 3);
    adminGrid.add(instructorRoleCheckBox, 1, 4);
    adminGrid.add(backButton, 0, 5);
    adminGrid.add(inviteButton, 1, 5);

    // Set alignment for buttons
    GridPane.setHalignment(inviteButton, HPos.CENTER);
    GridPane.setHalignment(backButton, HPos.CENTER);

    // Set action for the invite button
    inviteButton.setOnAction(e -> triggerInvite(userNameEnter.getText(), emailEnter.getText(),
      adminRoleCheckBox.isSelected(), studentRoleCheckBox.isSelected(), instructorRoleCheckBox.isSelected()));

    // Set action for the back button
    backButton.setOnAction(e -> mainStage.setScene(new AdminPage(mainStage, UserAdminController).adminHomePage()));

    // Set the title for the main stage and return the scene
    mainStage.setTitle("Invite Page");
    return new Scene(adminGrid, 300, 275);
  }

  // Method to handle the invitation logic
  private void triggerInvite(String username, String email, boolean adminCheck, boolean studentCheck, boolean instructorCheck) {
    // Check if username or email is empty and show an error alert if so
    if (username.isEmpty() || email.isEmpty()) {
      Alert alert = new Alert(Alert.AlertType.ERROR, "Username or Email is empty!");
      alert.showAndWait();
      return;
    }

    // Set to hold selected roles
    Set<Role> role = new HashSet<>();
    if (adminCheck) {
      role.add(Role.ADMIN); 
    }
    if (studentCheck) {
      role.add(Role.STUDENT); 
    }
    if (instructorCheck) {
      role.add(Role.INSTRUCTOR);
    }

    // Check if no roles were selected and show an error alert
    if (role.isEmpty()) {
      Alert alert = new Alert(Alert.AlertType.ERROR, "Role is empty!");
      alert.showAndWait();
      return;
    }

    // Call the UserAdminController to invite the user and get the invite code
    String inviteCode = UserAdminController.userInvitation(username, email, role);

    // Show an information alert with the invite code or an error alert if invitation failed
    if (inviteCode != null) {
      Alert alert = new Alert(Alert.AlertType.INFORMATION, "Invite code: " + inviteCode);
      alert.showAndWait();
    } else {
      Alert alert = new Alert(Alert.AlertType.ERROR, "There was a problem sending the invitation");
      alert.showAndWait();
    }

    // Redirect to the admin home page after sending the invitation
    mainStage.setScene(new AdminPage(mainStage, UserAdminController).adminHomePage());
  }
}
