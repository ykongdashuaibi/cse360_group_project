package application;

import java.util.ArrayList;
import java.util.Set;
import java.util.List;
import java.util.UUID;


public class Invite {
  private String inviteCode; 
  private String user; 
  private String mail1; 
  private Set<Role> roles;
  private boolean checkedInvite; 

  private static List<Invite> invites = new ArrayList<>();

  // Constructor to create an invite
  public Invite(String username, String email, Set<Role> roles) {
    this.inviteCode = UUID.randomUUID().toString(); 
    this.user = username;
    this.mail1 = email;
    this.roles = roles;
    this.checkedInvite = false; 
  }


  // Get email
  public String emailGet() {
    return mail1; 
  }



  // Get username
  public String userNameGet() {
    return user; 
  }

  // Check if invite has been declared
  public boolean checkInvite() {
    return checkedInvite; 
  }
  
  // Get assigned roles
  public Set<Role> rolesGet() {
    return roles; 
  }


  // Get invitation code
  public String inviteCodeGet() {
    return inviteCode; 
  }

  // Mark the invite as used
  public void usedInvite() {
    this.checkedInvite = true; 
  }

  // Create a new invite and return the invite code
  public static String createInvite(String email, String username,  Set<Role> roles) {
    Invite invitation = new Invite(username, email, roles); 
    invites.add(invitation); 
    return invitation.inviteCodeGet(); 
  }

  // Find and return the invite if the code matches and is not declared
  public static Invite returnInvite(String inviteCode) {
    for (Invite invite : invites) {
      if (invite.inviteCodeGet().equals(inviteCode) && !invite.checkInvite()) {
        return invite; 
      }
    }
    return null; 
  }

  // Remove the invite based on the invitation code
  public static boolean unconfirm(String invitationCode) {
    return invites.removeIf(invite -> invite.inviteCodeGet().equals(invitationCode));
  }
}
