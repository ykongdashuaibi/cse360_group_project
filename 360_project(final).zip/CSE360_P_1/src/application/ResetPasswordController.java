package application;

import java.time.Instant;

public class ResetPasswordController {
  private String email;
  private String oneTimePass;
  private Instant expiry;

  public ResetPasswordController(String email, String oneTimePassword, Instant expirationTime) {
    this.email = email;
    this.oneTimePass = oneTimePassword;
    this.expiry = expirationTime;
  }

  public String getEmail() {
    return email;
  }
  
  public Instant expiryTime() {
	    return expiry;
	  }

  public String getOneTimePassword() {
    return oneTimePass;
  }

  public boolean expired() {
    return Instant.now().isAfter(expiry);
  }
}