//package application;
//
//import javafx.geometry.Insets;
//import javafx.geometry.Pos;
//import javafx.scene.Scene;
//import javafx.scene.control.*;
//import javafx.scene.layout.GridPane;
//import javafx.stage.Stage;
//
//public class LoginPage {
//  private Stage mainStage;
//  private UserAccessControl userAdminController;
//
//  public LoginPage(Stage mainStage, UserAccessControl userAdminController) {
//    this.mainStage = mainStage;
//    this.userAdminController = userAdminController;
//  }
//
//  public Scene triggerLoginSelection() {
//    mainStage.setTitle("Login Page");
//
//    GridPane grid = new GridPane();
//    grid.setAlignment(Pos.CENTER);
//    grid.setHgap(10);
//    grid.setVgap(10);
//    grid.setPadding(new Insets(25, 25, 25, 25));
//
//    //username
//    Label username_four = new Label("User name:");
//    grid.add(username_four, 0, 0);
//    TextField userName_enter = new TextField();
//    grid.add(userName_enter, 1, 0);
//
//    //password
//    Label pass_four = new Label("Password:");
//    grid.add(pass_four, 0, 1);
//    PasswordField pass_enter = new PasswordField();
//    grid.add(pass_enter, 1, 1);
//
//   //buttons to login and other actions
//    Button button_Login = new Button("Login");
//    Button button_passReset = new Button("One Time Password Login");
//    Button inviteCodeBtn = new Button("Invitation Code Login");
//    Button button_signUp = new Button("Sign Up");
//
//    // Adding buttons to the grid
//    grid.add(button_Login, 1, 3);
//    grid.add(button_passReset, 1, 4);
//    grid.add(inviteCodeBtn, 1, 5);
//    grid.add(button_signUp, 1, 6); 
//
//   //Set the button Actions
//    button_Login.setOnAction(e -> handleLogin(userName_enter.getText(), pass_enter.getText()));
//    button_passReset.setOnAction(e ->
//      mainStage.setScene(new ResetPasswordPage(mainStage, userAdminController).createPasswordResetScene()));
//    inviteCodeBtn.setOnAction(e ->
//      mainStage.setScene(new InviteCodeAccessPage(mainStage, userAdminController).inviteCodePage())); // Corrected method name
//    button_signUp.setOnAction(e ->
//      mainStage.setScene(new SignUpPage(mainStage, userAdminController).triggerAdminPage())); // Navigate to Sign Up
//
//    return new Scene(grid, 300, 275);
//  }
//
//  private void handleLogin(String username, String password) {
//    User user = userAdminController.implementChecker(username, password);
//    if (user != null) {
//      if (!user.detectCompleteSetup()) {
//        mainStage.setScene(new AccountSetUpPage(user, userAdminController, mainStage).setUpPage());
//      } else {
//        new SelectRolePage(mainStage, userAdminController).handleRoleSelection(user);
//      }
//    } else {
//      new DisplayError().showError("Incorrect password or username!");
//    }
//  }
//}

package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import application_phase2.HelpSystem;

public class LoginPage {
    private Stage mainStage;
    private UserAccessControl userAdminController;
    private HelpSystem helpSystem; // Added HelpSystem reference

    // Updated constructor to include HelpSystem
    public LoginPage(Stage mainStage, UserAccessControl userAdminController, HelpSystem helpSystem) {
        this.mainStage = mainStage;
        this.userAdminController = userAdminController;
        this.helpSystem = helpSystem;
    }

    public Scene triggerLoginSelection() {
        mainStage.setTitle("Login Page");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        // Username field
        Label usernameLabel = new Label("User name:");
        grid.add(usernameLabel, 0, 0);
        TextField usernameField = new TextField();
        grid.add(usernameField, 1, 0);

        // Password field
        Label passwordLabel = new Label("Password:");
        grid.add(passwordLabel, 0, 1);
        PasswordField passwordField = new PasswordField();
        grid.add(passwordField, 1, 1);

        // Login and other action buttons
        Button loginButton = new Button("Login");
        Button resetPasswordButton = new Button("One Time Password Login");
        Button inviteCodeButton = new Button("Invitation Code Login");
        Button signUpButton = new Button("Sign Up");

        // Adding buttons to the grid
        grid.add(loginButton, 1, 3);
        grid.add(resetPasswordButton, 1, 4);
        grid.add(inviteCodeButton, 1, 5);
        grid.add(signUpButton, 1, 6);

        // Set button actions
        loginButton.setOnAction(e -> handleLogin(usernameField.getText(), passwordField.getText()));
        resetPasswordButton.setOnAction(e ->
            mainStage.setScene(new ResetPasswordPage(mainStage, userAdminController).createPasswordResetScene()));
        inviteCodeButton.setOnAction(e ->
            mainStage.setScene(new InviteCodeAccessPage(mainStage, userAdminController).inviteCodePage()));
        signUpButton.setOnAction(e ->
            mainStage.setScene(new SignUpPage(mainStage, userAdminController).triggerAdminPage()));

        return new Scene(grid, 300, 275); // Directly returning the Scene
    }

    private void handleLogin(String username, String password) {
        User user = userAdminController.implementChecker(username, password);
        if (user != null) {
            if (!user.detectCompleteSetup()) {
                mainStage.setScene(new AccountSetUpPage(user, userAdminController, mainStage).setUpPage());
            } else {
                new SelectRolePage(mainStage, userAdminController).handleRoleSelection(user);
            }
        } else {
            new DisplayError().showError("Incorrect password or username!");
        }
    }
}
