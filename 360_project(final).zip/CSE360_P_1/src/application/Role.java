package application;

public enum Role {
 ADMIN,
 STUDENT,
 INSTRUCTOR
}
