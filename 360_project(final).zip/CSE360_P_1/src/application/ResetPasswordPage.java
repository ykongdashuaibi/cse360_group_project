package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import application_phase2.HelpSystem;
public class ResetPasswordPage {
    private Stage mainStage; // The main application stage
    private UserAccessControl userAdminController; // Controller for user access and management
    private HelpSystem helpSystem;
    
    // Constructor to initialize the ResetPasswordPage with the main stage and user admin controller
    public ResetPasswordPage(Stage mainStage, UserAccessControl userAdminController) {
        this.userAdminController = userAdminController;
        this.mainStage = mainStage;
        this.helpSystem = userAdminController.getHelpSystem();
    }

    // Method to create the password reset scene
    public Scene createPasswordResetScene() {
        mainStage.setTitle("Reset Password"); 

    
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

   
        Label email2 = new Label("Enter your email:");
        TextField emailEnter = new TextField();

        Label oneTime = new Label("One time Password:");
        TextField oneTimeEnter = new TextField();

        Label newPass = new Label("Enter new password:");
        PasswordField newPassEnter = new PasswordField();

        Label confirmationPass = new Label("Confirm new password:");
        PasswordField confirmationPassEnter = new PasswordField();

        // Create buttons for actions
        Button submitButton = new Button("Save"); 
        Button back2 = new Button("Back to Login"); 

        // Add elements to the grid
        grid.add(email2, 0, 0);
        grid.add(emailEnter, 1, 0);
        grid.add(oneTime, 0, 1);
        grid.add(oneTimeEnter, 1, 1);
        grid.add(newPass, 0, 2);
        grid.add(newPassEnter, 1, 2);
        grid.add(confirmationPass, 0, 3);
        grid.add(confirmationPassEnter, 1, 3);
        grid.add(submitButton, 1, 4);
        grid.add(back2, 1, 5);

        // Action handler for the "Back" button
        back2.setOnAction(e ->
            mainStage.setScene(new LoginPage(mainStage, userAdminController, helpSystem).triggerLoginSelection()));

        // Action handler for the "Submit" button
        submitButton.setOnAction(event -> {
            String emailThree = emailEnter.getText(); 
            String oneTimePassword_One = oneTimeEnter.getText(); 
            String updatedPassword = newPassEnter.getText();
            String passwordConfirmation = confirmationPassEnter.getText(); 

            // Request the reset password details from the user admin controller
            ResetPasswordController request = userAdminController.accessEmailAsk(emailThree);

            if (request == null || request.expired()) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid or expired reset request.");
                alert.showAndWait();
                return; 
            }

        
            if (!oneTimePassword_One.equals(request.getOneTimePassword())) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "One time password is invalid!");
                alert.showAndWait();
                return; 
            }

          
            if (!updatedPassword.equals(passwordConfirmation)) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Passwords do not match!");
                alert.showAndWait();
                return; 
            }

            // Update the user's password and discard the request
            userAdminController.newUserUpdate(emailThree, updatedPassword);
            userAdminController.discard(request);

            // Show success alert and navigate to the login page
            Alert success = new Alert(Alert.AlertType.INFORMATION, "Password is reset!");
            success.showAndWait();
            mainStage.setScene(new LoginController(mainStage, userAdminController, helpSystem).triggerLoginPage());
        });

        return new Scene(grid, 300, 275); 
    }
}
