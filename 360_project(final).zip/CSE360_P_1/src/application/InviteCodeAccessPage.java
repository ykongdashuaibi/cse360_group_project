package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import application_phase2.HelpSystem;

public class InviteCodeAccessPage {
  private Stage mainStage; // Main application stage
  private UserAccessControl userAdminController; // Controller for user access management
  private HelpSystem helpSystem;

  public InviteCodeAccessPage(Stage mainStage, UserAccessControl userAdminController) {
    this.mainStage = mainStage; // Initialize main stage
    this.userAdminController = userAdminController; // Initialize user access controller
    this.helpSystem = userAdminController.getHelpSystem();
  }

  // Method to create the scene for invite code access
  public Scene inviteCodePage() {
    mainStage.setTitle("Invitation Code Page"); 
    GridPane grid = new GridPane(); 
    grid.setAlignment(Pos.CENTER); 
    grid.setHgap(10); 
    grid.setVgap(10);
    grid.setPadding(new Insets(25, 25, 25, 25)); 

    Label inviteCode = new Label("Invitation Code:"); 
    grid.add(inviteCode, 0, 0); 

    TextField inviteCodeEnter = new TextField();
    grid.add(inviteCodeEnter, 1, 0); 

    Button loginButton = new Button("Login"); 
    grid.add(loginButton, 1, 1);

    Button backToLoginButton = new Button("<-- Back"); 
    grid.add(backToLoginButton, 0, 1);

    // Set action for the login button
    loginButton.setOnAction(e -> handleInvitationCodeLogin(inviteCodeEnter.getText()));
    // Set action for the back button
    //backToLoginButton.setOnAction(e -> mainStage.setScene(new LoginPage(mainStage, userAdminController).triggerLoginSelection()));
    backToLoginButton.setOnAction(e -> mainStage.setScene(new LoginPage(mainStage, userAdminController, helpSystem).triggerLoginSelection()));

    return new Scene(grid, 300, 275);
  }

  // Method to handle the invitation code login process
  private void handleInvitationCodeLogin(String invitationCode) {
    if (userAdminController.checkUserInvite(invitationCode)) { 
      // If valid, transition to the password entry scene
      mainStage.setScene(new InvitePasswordCode(invitationCode, userAdminController, mainStage).newPassword());
    } else {
      // Show an error if the invitation code is invalid
      new DisplayError().showError("Invalid invitation code.");
    }
  }
}
