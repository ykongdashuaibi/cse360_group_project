package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class PasswordResetPage {
    private Stage mainStage; // The main application stage
    private UserAccessControl userAdminController; // Controller for user access and management

    // Constructor to initialize the PasswordResetPage with the main stage and user admin controller
    public PasswordResetPage(Stage mainStage, UserAccessControl userAdminController) {
        this.mainStage = mainStage;
        this.userAdminController = userAdminController;
    }

    // Method to create the password resetting scene
    public Scene Resetting() {
        mainStage.setTitle("Password Reset Page"); 

        // Create a layout for the scene using a GridPane
        GridPane layout = new GridPane();
        layout.setAlignment(Pos.CENTER); 
        layout.setVgap(10); 
        layout.setHgap(10); 
        layout.setPadding(new Insets(25, 25, 25, 25)); 

        // Create labels and input fields for email entry
        Label email = new Label("Email:");
        TextField emailEnter = new TextField(); 

        // Create buttons for actions
        Button go = new Button("Go");
        Button back = new Button("<-- Back"); 

        // Add elements to the layout
        layout.add(email, 0, 0); 
        layout.add(emailEnter, 1, 0); 
        layout.add(back, 0, 1); 
        layout.add(go, 1, 1); 

        // Action handler for the "Go" button
        go.setOnAction(e -> {
            String mail1 = emailEnter.getText(); // Get the text entered in the email field

            // Check if the email field is empty
            if (mail1.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Please put in an email!"); // Show error alert
                alert.showAndWait(); // Wait for user to acknowledge the alert
            } 
            // Check if the entered email is valid
            else if (!userAdminController.emailNotEmpty(mail1)) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Incorrect email"); // Show error alert for incorrect email
                alert.showAndWait(); // Wait for user to acknowledge the alert
            } 
            // If email is valid, proceed with password reset
            else {
                userAdminController.passwordResetAsk(mail1);
                Alert success = new Alert(Alert.AlertType.INFORMATION, "Password reset success"); 
                success.showAndWait(); 

                emailEnter.clear(); // Clear the email input field
            }
        });

        // Action handler for the "Back" button
        back.setOnAction(e -> {
            AdminPage adminHomePage = new AdminPage(mainStage, userAdminController);
            mainStage.setScene(adminHomePage.adminHomePage()); 
        });

        return new Scene(layout, 300, 275); 
    }
}
