package application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import application_phase2.HelpSystem;

public class InvitePasswordCode {
  // Invitation code for the password reset process
  private String invitationCode;
  // User access control for managing user actions
  private UserAccessControl UserControlCenter;
  // Main stage for displaying scenes
  private Stage mainStage;
  private HelpSystem helpSystem;

  // Constructor initializing invitation code, user control center, and main stage
  public InvitePasswordCode(String inviteCode, UserAccessControl UserControlCenter, Stage mainStage) {
    this.mainStage = mainStage;
    this.invitationCode = inviteCode;
    this.UserControlCenter = UserControlCenter;
    this.helpSystem = UserControlCenter.getHelpSystem();
  }

  // Method to create the new password entry scene
  public Scene newPassword() {
    // Label and field for entering a new password
    Label enterPassword = new Label("Enter new password:");
    PasswordField password_Field = new PasswordField();

    // Label and field for confirming the new password
    Label confirmPass = new Label("Confirm new password:");
    PasswordField confirmPassEnter = new PasswordField();

    // Submit button to finalize password entry
    Button submit = new Button("Submit");
    submit.setOnAction(event -> {
      // Get the entered passwords
      String password = password_Field.getText();
      String confirmPassword = confirmPassEnter.getText();

      // Check if the entered passwords match
      if (password.equals(confirmPassword)) {
        Invite invite = UserControlCenter.invitecodeGetinvite(invitationCode);
        UserControlCenter.implementUser(invite.userNameGet(), password, invite.rolesGet());
        UserControlCenter.deleteUserInvite(invitationCode);
        mainStage.setScene(new LoginController(mainStage, UserControlCenter, helpSystem).triggerLoginPage());
      } else {
        System.out.println("Passwords do not match!");
      }
    });

    // Layout for the password entry scene
    VBox layout = new VBox(10, enterPassword, password_Field, confirmPass, confirmPassEnter, submit);
    return new Scene(layout, 300, 275); 
  }
}
