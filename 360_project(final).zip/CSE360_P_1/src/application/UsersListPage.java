package application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.control.ScrollPane;
import javafx.stage.Stage;
import java.util.List;

public class UsersListPage {
  private Stage primaryStage;
  private UserAccessControl userAdminController;
  private Button backButton;
  private GridPane grid;

  public UsersListPage(Stage primaryStage, UserAccessControl userAdminController) {
    primaryStage.setTitle("List of Users Page");
    this.primaryStage = primaryStage;
    this.userAdminController = userAdminController;
    this.grid = new GridPane();
    grid.setAlignment(Pos.CENTER);
    grid.setVgap(10);
    grid.setHgap(10);
    grid.setPadding(new Insets(25, 25, 25, 25));
    initializeButtons();
  }

  private void initializeButtons() {
    backButton = new Button("Back");
    backButton.setOnAction(e -> primaryStage.setScene(new AdminPage(primaryStage, userAdminController).adminHomePage()));

    HBox buttonBox = new HBox(10);
    buttonBox.getChildren().addAll(backButton);
    buttonBox.setAlignment(Pos.CENTER);
    grid.add(buttonBox, 0, 0, 1, 1);
  }

  public Scene triggerUserList() {
    updateUserList();
    ScrollPane scrollPane = new ScrollPane(grid);
    scrollPane.setFitToWidth(true);
    scrollPane.setPrefHeight(600);
    return new Scene(scrollPane, 600, 600);
  }

  private void updateUserList() {
    grid.getChildren().removeIf(node -> node instanceof Label && GridPane.getRowIndex(node) > 0);
    List < User > allUsers = userAdminController.arrayUsers();
    for (int i = 0; i < allUsers.size(); i++) {
      User user = allUsers.get(i);
      Label userInfo = new Label("Name: " + user.getFirstName() + " " + user.getLastName() + "\n" +
        "Username: " + user.getUsername() + "\n" +
        "Roles: " + user.getRoles().toString());
      grid.add(userInfo, 0, i + 1);
    }
  }
}