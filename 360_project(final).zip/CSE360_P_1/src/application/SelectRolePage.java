package application;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Set;

public class SelectRolePage {
  private Stage mainStage;
  private UserAccessControl UserAdminController;

  public SelectRolePage(Stage mainStage, UserAccessControl UserAdminController) {
    this.mainStage = mainStage;
    this.UserAdminController = UserAdminController;
  }

  public void handleRoleSelection(User user) {
    Set < Role > roles = user.getRoles();

    if (roles.size() > 1) {
      // Create and set the role selection scene
      Scene roleSelectionPage = createRoleSelectionScene(user);
      mainStage.setScene(roleSelectionPage);
    } else if (roles.size() == 1) {
      // Navigate to the home page for the single role
      rolePage(user, roles.iterator().next());
    }
  }

  private Scene createRoleSelectionScene(User user) {
    GridPane roleSelectionGrid = new GridPane();
    roleSelectionGrid.setPrefSize(400, 300); 
    roleSelectionGrid.setVgap(15); 
    roleSelectionGrid.setHgap(15); 
    roleSelectionGrid.setPadding(new Insets(20, 20, 20, 20)); 

    Label label = new Label("Role:");
    roleSelectionGrid.add(label, 0, 0, 2, 1);

    Set < Role > roles = user.getRoles();
    int rowIndex = 1; 

   
    for (Role role: roles) {
      Button roleButton = new Button(role.toString());
      roleButton.setPrefWidth(150); 
      roleButton.setOnAction(event -> {
        rolePage(user, role); 
      });
      roleSelectionGrid.add(roleButton, 0, rowIndex); 
      Label roleDescription = new Label("Description for " + role); 
      roleSelectionGrid.add(roleDescription, 1, rowIndex); 

      rowIndex++; 
    }

    return new Scene(roleSelectionGrid, 300, 275); 
  }

  private void rolePage(User user, Role role) {
    switch (role) {
    case ADMIN:
      mainStage.setScene(new AdminPage(mainStage, UserAdminController).adminHomePage());
      break;
    case STUDENT:
      mainStage.setScene(new StudentHomePage(mainStage, UserAdminController).studentHomePage());
      break;
    case INSTRUCTOR:
      mainStage.setScene(new InstructorHomePage(mainStage, UserAdminController).instructorHomePage());
      break;
    default:
      new DisplayError().showError("Invalid role!");
    }
  }
}