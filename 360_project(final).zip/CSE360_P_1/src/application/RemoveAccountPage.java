package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class RemoveAccountPage {
  private Stage mainStage;
  private UserAccessControl userAdminController;

  public RemoveAccountPage(Stage mainStage, UserAccessControl userAdminController) {
    this.mainStage = mainStage;
    this.userAdminController = userAdminController;
  }

  public Scene deleteUserCreate() {
    // Create GridPane layout
    mainStage.setTitle("Remove account page");
    GridPane layout = new GridPane();
    layout.setAlignment(Pos.CENTER);
    layout.setVgap(10); 
    layout.setHgap(10);
    layout.setPadding(new Insets(25, 25, 25, 25)); 

    // UI Components
    Label userName = new Label("Username:");
    TextField userNameEnter = new TextField();
    userNameEnter.setPromptText("Username");

 
    Button removeBtn = new Button("Remove Account");
    removeBtn.setMaxWidth(Double.MAX_VALUE); 

    Button backButton = new Button("<-- Back");
    backButton.setMaxWidth(Double.MAX_VALUE);

    // Add components to the GridPane
    layout.add(userName, 0, 0); 
    layout.add(userNameEnter, 1, 0); 
    layout.add(removeBtn, 0, 1);
    layout.add(backButton, 0, 2); 

    // If user exists then prompt the delete button
    removeBtn.setOnAction(e -> {
      String username = userNameEnter.getText();
      User user = userAdminController.locateUser(username);

      if (user != null) {
        Alert userAlert = new Alert(Alert.AlertType.CONFIRMATION);
        userAlert.setTitle("This will delete the account");
        userAlert.setContentText("Deleting " + user.getUsername() + "?");

        userAlert.showAndWait().ifPresent(response -> {
          if (response == ButtonType.OK) {
            userAdminController.userDelete(user);
            Alert deletion = new Alert(Alert.AlertType.INFORMATION);
            deletion.setTitle("Deleted");
            deletion.setHeaderText(null);
            deletion.setContentText(user.getUsername() + " is deleted");
            deletion.showAndWait();
            userNameEnter.clear();
          } else {
            Alert removed = new Alert(Alert.AlertType.INFORMATION);
            removed.setTitle("Nevermind");
            removed.setHeaderText(null);
            removed.setContentText("Cancel");
            removed.showAndWait();
          }
        });
      } else {
        // User not found error
        Alert notifyError = new Alert(Alert.AlertType.ERROR);
        notifyError.setTitle("Error");
        notifyError.setHeaderText(null);
        notifyError.setContentText("There is no username for this");
        notifyError.showAndWait();
      }
    });

    // Action for the back button
    backButton.setOnAction(e -> mainStage.setScene(new AdminPage(mainStage, userAdminController).adminHomePage()));

    return new Scene(layout, 300, 275); // Return the scene with the grid layout
  }
}