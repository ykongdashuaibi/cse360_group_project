package application;

import javafx.application.Application;
import javafx.stage.Stage;
import application_phase2.HelpSystem;
import application.LoginPage;
import application.UserAccessControl;


public class Main extends Application {
    private static HelpSystem helpSystem;
    private static UserAccessControl userAdminController;

    @Override
    public void start(Stage primaryStage) {
        try {
            // Initialize HelpSystem
            helpSystem = new HelpSystem();

            // Initialize UserAccessControl and pass HelpSystem
            userAdminController = new UserAccessControl(helpSystem);
            userAdminController.loadUsersFromFile();
            helpSystem.setUserAdminController(userAdminController); // Set the controller

            // Set up the Login Page
            LoginPage loginPage = new LoginPage(primaryStage, userAdminController, helpSystem);
            primaryStage.setTitle("Help System — Login");
            primaryStage.setScene(loginPage.triggerLoginSelection());
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to initialize the Help System.");
        }
    }

    @Override
    public void stop() {
        try {
            // Save users to the file before exiting
            if (userAdminController != null) {
                userAdminController.saveUsersToFile();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to save user data.");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
