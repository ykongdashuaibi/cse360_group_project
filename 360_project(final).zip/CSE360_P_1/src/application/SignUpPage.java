package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import application_phase2.HelpSystem;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import javafx.collections.FXCollections;

public class SignUpPage {
  private UserAccessControl userAdminController;
  private Stage mainStage;
  private HelpSystem helpSystem;
  private List<User> controlUser;
  
  public SignUpPage(Stage mainStage, UserAccessControl userAdminController) {
    this.userAdminController = userAdminController;
    this.mainStage = mainStage;
    this.helpSystem = userAdminController.getHelpSystem();
    this.controlUser = new ArrayList<>();
  }

  public Scene triggerAdminPage() {
	  mainStage.setTitle("SignUp (Default Admin)");
//grid work for padding
    GridPane grid = new GridPane();
    grid.setAlignment(Pos.CENTER);
    grid.setHgap(10);
    grid.setVgap(10);
    grid.setPadding(new Insets(25, 25, 25, 25));


    Label username = new Label("Username:");
    TextField usernameEnter = new TextField();
    Label password = new Label("Password:");
    PasswordField passwordEnter = new PasswordField();
    Label confirmPassword = new Label("Confirm Password:");
    PasswordField confirmPasswordEnter = new PasswordField();
    Button SignUp = new Button("Sign up");
    Label label = new Label(); 
// Role selection ComboBox
//    Label roleLabel = new Label("Select Role:");
//    ComboBox<Role> roleComboBox = new ComboBox<>(FXCollections.observableArrayList(Role.ADMIN, Role.STUDENT, Role.INSTRUCTOR));
//    roleComboBox.setValue(Role.ADMIN); // Default value
//    Button SignUp = new Button("Sign up");
//    Label label = new Label();

    grid.add(username, 0, 0);
    grid.add(usernameEnter, 1, 0);
    grid.add(password, 0, 1);
    grid.add(passwordEnter, 1, 1);
    grid.add(confirmPassword, 0, 2);
    grid.add(confirmPasswordEnter, 1, 2);
    grid.add(SignUp, 1, 3);
    grid.add(label, 1, 4);

    
    SignUp.setOnAction(e -> handleCreateAdmin(usernameEnter.getText(),
      passwordEnter.getText(), confirmPasswordEnter.getText(), label));

    return new Scene(grid, 300, 275); 
  }

  private void handleCreateAdmin(String username, String password, String confirmPassword,
    Label confirmationLabel) {
 
    confirmationLabel.setText("");

    
    if (username == null || username.isEmpty()) {
      showAlert("Error", "Username cannot be empty!");
      return; 
    }

    if (password == null || password.isEmpty()) {
      showAlert("Error", "Password cannot be empty!");
      return; 
    }

    if (confirmPassword == null || confirmPassword.isEmpty()) {
      showAlert("Error", "Confirm Password cannot be empty!");
      return; 
    }

    if (!password.equals(confirmPassword)) {
      showAlert("Error", "Passwords do not match!");
      return; 
    }

    // Proceed to create the first user as an admin
    User admin = userAdminController.hashUser(username, password);

    if (admin != null) {
    	mainStage.setScene(new LoginController(mainStage, userAdminController,helpSystem).triggerLoginPage());
    }
  }

  // Method to show an alert dialog
  private void showAlert(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
  }

  private void handleSignUp(String username, String password, Role selectedRole) {
	    // Create a set containing only the selected role
	    Set<Role> roles = new HashSet<>(Collections.singletonList(selectedRole));
	    userAdminController.implementUser(username, password, roles);
	    userAdminController.saveUsersToFile(); // Save the user data after signup
	}


}