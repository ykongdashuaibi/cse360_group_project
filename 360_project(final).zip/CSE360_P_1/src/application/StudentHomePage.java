package application;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import application_phase2.HelpSystem;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import application_phase2.Article;

public class StudentHomePage {
    private Stage primaryStage;
    private UserAccessControl UserAdminController;
    private HelpSystem helpSystem;

    public StudentHomePage(Stage primaryStage, UserAccessControl UserAdminController) {
        this.primaryStage = primaryStage;
        this.UserAdminController = UserAdminController; // Store the authManager
        this.helpSystem = UserAdminController.getHelpSystem();
    }

    public Scene studentHomePage() {
        GridPane homeGrid = new GridPane();
        homeGrid.setPrefSize(400, 400);
        homeGrid.setVgap(10); // Vertical gap between elements
        homeGrid.setHgap(10); // Horizontal gap between elements
        homeGrid.setPadding(new Insets(20, 20, 20, 20)); // Padding around the grid

        Label welcomeLabel = new Label("Hello User!");
        Button logoutButton = new Button("Logout");
        Button quitButton = new Button("Quit Application");
        Button sendGenericMessageButton = new Button("Send Generic Message");
        Button sendSpecificMessageButton = new Button("Send Specific Message");

        // Search related components
        TextField searchTextField = new TextField();
        searchTextField.setPromptText("Search for title");

        ComboBox<String> levelComboBox = new ComboBox<>();
        levelComboBox.getItems().addAll("Beginner", "Intermediate", "Advanced", "Expert", "All");
        levelComboBox.setValue("All"); // Default level is "All"

        ComboBox<String> groupComboBox = new ComboBox<>();
        groupComboBox.getItems().addAll("All", "Group 1", "Group 2"); // Add your groups here
        groupComboBox.setValue("All"); // Default group is "All"

        Button searchButton = new Button("Search");

        // Actions for the buttons
        logoutButton.setOnAction(e -> handleLogout());
        quitButton.setOnAction(e -> System.exit(0));
        sendGenericMessageButton.setOnAction(e -> sendGenericMessage());
        sendSpecificMessageButton.setOnAction(e -> sendSpecificMessage());

        searchButton.setOnAction(e -> performSearch(searchTextField.getText(), levelComboBox.getValue(), groupComboBox.getValue()));

        // Add components to the grid
        homeGrid.add(welcomeLabel, 0, 0, 2, 1);
        homeGrid.add(logoutButton, 0, 1);
        homeGrid.add(quitButton, 1, 1);
        homeGrid.add(sendGenericMessageButton, 0, 2);
        homeGrid.add(sendSpecificMessageButton, 1, 2);
        homeGrid.add(searchTextField, 0, 3, 2, 1);
        homeGrid.add(levelComboBox, 0, 4);
        homeGrid.add(groupComboBox, 1, 4);
        homeGrid.add(searchButton, 0, 5, 2, 1);

        primaryStage.setTitle("Student Home Page");
        return new Scene(homeGrid, 400, 400);
    }

    private void handleLogout() {
        // Navigate back to the login scene
        LoginController loginScene = new LoginController(primaryStage, UserAdminController, helpSystem);
        primaryStage.setScene(loginScene.triggerLoginPage());
    }

    private void sendGenericMessage() {
        // Send a generic message to the help system
        String genericMessage = "I need help using the tool. It is unclear how to proceed.";
        helpSystem.sendMessage(genericMessage);
        showMessage("Your generic message has been sent to the help system.");
    }

    private void sendSpecificMessage() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Specific Help Message");
        dialog.setHeaderText("Specify the help you need:");
        dialog.setContentText("What can you not find?");

        dialog.showAndWait().ifPresent(userInput -> {
            List<String> searchRequests = helpSystem.getSearchRequestsAsList(); // Get the student's search history
            String specificMessage = "Student cannot find: " + userInput + "\nSearch Requests: " +
                                     (searchRequests.isEmpty() ? "None" : String.join(", ", searchRequests));
            helpSystem.sendMessage(specificMessage); // Send the message to HelpSystem
            showMessage("Your specific message has been sent to the help system.");
        });
    }


//    private void performSearch(String searchQuery, String level, String group) {
//        // Perform the search based on user input
//        // Display the search results (you'll need to implement the search logic in your HelpSystem class)
//        helpSystem.searchArticles(searchQuery);
//
//        // Show search results (assumed method for displaying search results)
//        showMessage("Search completed.");
//    }

    private void showMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Search Results");
        alert.setHeaderText(null);

        // Create a scrollable TextArea for multi-line output
        TextArea textArea = new TextArea(message);
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setPrefSize(400, 300); // Adjust size as needed

        alert.getDialogPane().setContent(textArea);
        alert.showAndWait();
    }

    
    //new code for phase 4
    private void performSearch(String searchQuery, String level, String group) {
        // Get the filtered results
        List<Article> results = helpSystem.searchArticles(searchQuery, level, group);

        // Build the output message
        StringBuilder output = new StringBuilder();

        // Display active group
        String activeGroup = group != null ? group : "All";
        output.append("Active Group: ").append(activeGroup).append("\n");

        // Count and display articles by level
        Map<String, Long> levelCounts = results.stream()
            .collect(Collectors.groupingBy(Article::getLevel, Collectors.counting()));
        output.append("Articles by Level:\n");
        levelCounts.forEach((lvl, count) -> output.append("  ").append(lvl).append(": ").append(count).append(" articles\n"));

        // Display matching articles in short form
        if (results.isEmpty()) {
            output.append("\nNo articles match your search criteria.");
        } else {
            output.append("\nMatching Articles:\n");
            for (int i = 0; i < results.size(); i++) {
                Article article = results.get(i);
                output.append((i + 1)).append(". Title: ").append(article.getTitle())
                      .append(" | ID: ").append(article.getId())
                      .append(" | Abstract: ").append(article.getShortDescription())
                      .append("\n");
            }
        }

        // Display the output in a dialog
        showMessage(output.toString());

        // Provide options for the next action
        handlePostSearchActions(results);
    }


    private void handlePostSearchActions(List<Article> results) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Search Options");
        dialog.setHeaderText("Choose an action:\n1. Perform another search\n2. View an article in detail (Enter sequence number)\n3. Logout\n4. Quit Application");
        dialog.setContentText("Enter your choice:");

        dialog.showAndWait().ifPresent(input -> {
            try {
                int choice = Integer.parseInt(input);
                switch (choice) {
                    case 1:
                        // Perform another search
                        performAnotherSearch();
                        break;
                    case 2:
                        // View an article in detail
                        TextInputDialog articleDialog = new TextInputDialog();
                        articleDialog.setTitle("View Article");
                        articleDialog.setHeaderText("Enter the sequence number of the article to view:");
                        articleDialog.setContentText("Sequence number:");

                        articleDialog.showAndWait().ifPresent(articleInput -> {
                            try {
                                int articleIndex = Integer.parseInt(articleInput) - 1;
                                if (articleIndex >= 0 && articleIndex < results.size()) {
                                    viewArticleDetails(results.get(articleIndex));
                                } else {
                                    showMessage("Invalid sequence number. Please try again.");
                                    handlePostSearchActions(results);
                                }
                            } catch (NumberFormatException e) {
                                showMessage("Invalid input. Please enter a valid sequence number.");
                                handlePostSearchActions(results);
                            }
                        });
                        break;
                    case 3:
                        handleLogout();
                        break;
                    case 4:
                        System.exit(0);
                        break;
                    default:
                        showMessage("Invalid choice. Please try again.");
                        handlePostSearchActions(results);
                }
            } catch (NumberFormatException e) {
                showMessage("Invalid input. Please try again.");
                handlePostSearchActions(results);
            }
        });
    }

    // Method for "Perform another search"
    private void performAnotherSearch() {
        Dialog<ButtonType> searchDialog = new Dialog<>();
        searchDialog.setTitle("Perform Another Search");

        // Add fields for new search input
        TextField searchQueryField = new TextField();
        searchQueryField.setPromptText("Enter search query");

        ComboBox<String> levelComboBox = new ComboBox<>();
        levelComboBox.getItems().addAll("Beginner", "Intermediate", "Advanced", "Expert", "All");
        levelComboBox.setValue("All");

        ComboBox<String> groupComboBox = new ComboBox<>();
        groupComboBox.getItems().addAll("All", "Group 1", "Group 2");
        groupComboBox.setValue("All");

        GridPane searchGrid = new GridPane();
        searchGrid.setHgap(10);
        searchGrid.setVgap(10);
        searchGrid.add(new Label("Search Query:"), 0, 0);
        searchGrid.add(searchQueryField, 1, 0);
        searchGrid.add(new Label("Level:"), 0, 1);
        searchGrid.add(levelComboBox, 1, 1);
        searchGrid.add(new Label("Group:"), 0, 2);
        searchGrid.add(groupComboBox, 1, 2);

        searchDialog.getDialogPane().setContent(searchGrid);
        searchDialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Handle the input when "OK" is clicked
        searchDialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                String newSearchQuery = searchQueryField.getText();
                String newLevel = levelComboBox.getValue();
                String newGroup = groupComboBox.getValue();

                // Perform the search with new parameters
                performSearch(newSearchQuery, newLevel, newGroup);
            }
        });
    }


    private void viewArticleDetails(Article article) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Article Details");
        alert.setHeaderText("Title: " + article.getTitle());
        alert.setContentText("Level: " + article.getLevel() + "\nAbstract: " + article.getShortDescription() 
            + "\nKeywords: " + article.getKeywords() + "\nBody: " + article.getBody() 
            + "\nReferences: " + article.getReferences());
        alert.showAndWait();

        // After viewing, allow further actions
        handlePostArticleActions();
    }

    private void handlePostArticleActions() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Article Options");
        dialog.setHeaderText("Choose an action:\n1. Perform another search\n2. View another article in detail (Enter sequence number)\n3. Logout\n4. Quit Application");
        dialog.setContentText("Enter your choice:");

        dialog.showAndWait().ifPresent(input -> {
            try {
                int choice = Integer.parseInt(input);
                switch (choice) {
                    case 1:
                    	performAnotherSearch();
                        break;
                    case 2:
                        // View another article
                    	handleViewAnotherArticle();
                        break;
                    case 3:
                        handleLogout();
                        break;
                    case 4:
                        System.exit(0);
                        break;
                    default:
                        showMessage("Invalid choice. Please try again.");
                        handlePostArticleActions();
                }
            } catch (NumberFormatException e) {
                showMessage("Invalid input. Please try again.");
                handlePostArticleActions();
            }
        });
    }

 // Case 2: View another article in detail
    private void handleViewAnotherArticle() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("View Article");
        dialog.setHeaderText("Enter the sequence number of the article to view:");
        dialog.setContentText("Sequence number:");

        dialog.showAndWait().ifPresent(input -> {
            try {
                int sequenceNumber = Integer.parseInt(input);
                List<Article> results = helpSystem.getAllArticles(); // Get all articles (assume HelpSystem has this method)
                
                if (sequenceNumber >= 1 && sequenceNumber <= results.size()) {
                    Article selectedArticle = results.get(sequenceNumber - 1);
                    viewArticleDetails(selectedArticle);
                } else {
                    showMessage("Invalid sequence number. Please try again.");
                    handlePostArticleActions();
                }
            } catch (NumberFormatException e) {
                showMessage("Invalid input. Please enter a valid sequence number.");
                handlePostArticleActions();
            }
        });
    }

}
