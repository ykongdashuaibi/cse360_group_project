//package application;
//import java.time.temporal.ChronoUnit;
//import java.time.Instant;
//import java.util.*;
//
//public class UserAccessControl {
//  // List to store password reset requests
//  private List<ResetPasswordController> reset;
//
//  // List to store sent invites
//  private List<Invite> invite;
//
//  // List to store all registered users
//  private List<User> controlUser;
//
//  // Constructor initializing empty lists for users, invites, and password resets
//  public UserAccessControl() {
//    this.reset = new ArrayList<>();
//    this.controlUser = new ArrayList<>();
//    this.invite = new ArrayList<>();
//  }
//
//  // Finalize user setup by setting user details and marking setup as complete
//  public boolean finalize(User user, String firstName, String middleName, String lastName,
//                          String preferredName, String email) {
//    user.setEmail(email);
//    user.setFirstName(firstName);
//    user.setMiddleName(middleName);
//    user.setLastName(lastName);
//    user.setPreferredName(preferredName);
//    user.completedSetup(true); // Mark setup as complete
//    return true;
//  }
//
//  // Create and add a new user to the controlUser list
//  public User implementUser(String username, String password, Set<Role> roles) {
//    User newUser = new User(username, password, roles);
//    controlUser.add(newUser);
//    return newUser;
//  }
//
//  // Check if a user with the given username and password exists in controlUser
//  public User implementChecker(String username, String password) {
//    return controlUser.stream()
//      .filter(user -> user.getUsername().equals(username) && user.getPassword().equals(password))
//      .findFirst()
//      .orElse(null);
//  }
//  
//  // Create an admin user if no users exist
//  public User hashUser(String username, String password) {
//    if (controlUser.isEmpty()) {
//      User admin = new User(username, password, new HashSet<>(Collections.singletonList(Role.ADMIN)));
//      controlUser.add(admin);
//      return admin;
//    }
//    return null;
//  }
//
//  // Find and return a user by their username
//  public User locateUser(String username) {
//    return controlUser.stream()
//      .filter(user -> user.getUsername().equals(username))
//      .findFirst()
//      .orElse(null);
//  }
//
//  // Print details of all users in the controlUser list
//  public void listUsers() {
//    controlUser.forEach(user -> {
//      System.out.println("Username: " + user.getUsername());
//      System.out.println("Name: " + user.getFirstName() + " " + user.getLastName());
//      System.out.println("Roles: " + user.getRoles());
//      System.out.println("Setup Complete: " + user.detectCompleteSetup());
//      System.out.println();
//    });
//  }
//
//  // Return a list of all users
//  public List<User> arrayUsers() {
//    return new ArrayList<>(controlUser);
//  }
//
//  // Add a role to a user
//  public void roleImplement(User user, Role role) {
//    user.getRoles().add(role);
//  }
//
//  // Remove a role from a user
//  public void roleRemove(User user, Role role) {
//    user.getRoles().remove(role);
//  }
//
//  // Remove a user from the controlUser list
//  public boolean userDelete(User user) {
//    return controlUser.remove(user);
//  }
//
//  // Create and send an invitation to a user, returning the invite code
//  public String userInvitation(String username, String email, Set<Role> roles) {
//    Invite inviteNew = new Invite(username, email, roles);
//    invite.add(inviteNew);
//    System.out.println("Code: " + inviteNew.inviteCodeGet());
//    return inviteNew.inviteCodeGet();
//  }
//
//  // Check if an invitation code is valid and not yet used
//  public boolean checkUserInvite(String invitationCode) {
//    return invite.stream()
//      .anyMatch(invitation -> invitation.inviteCodeGet().equals(invitationCode) && !invitation.checkInvite());
//  }
//
//  // Retrieve an invite by its code
//  public Invite invitecodeGetinvite(String invitationCode) {
//    return invite.stream()
//      .filter(invitation -> invitation.inviteCodeGet().equals(invitationCode))
//      .findFirst()
//      .orElse(null);
//  }
//  
//  // Request a password reset and generate a one-time password
//  public void passwordResetAsk(String email) {
//    String oneTimePassword = makePass();
//    Instant expirationTime = Instant.now().plus(3, ChronoUnit.DAYS); // Set expiration in 3 days
//    System.out.println(email + "'s one time password is " + oneTimePassword + " Expiration:" + expirationTime);
//    reset.add(new ResetPasswordController(email, oneTimePassword, expirationTime));
//  }
//
//  // Delete an invitation by its code
//  public void deleteUserInvite(String invitationCode) {
//    invite.removeIf(invitation -> invitation.inviteCodeGet().equals(invitationCode));
//  }
//
//  // Print details of all invitations
//  public void inviteLists() {
//    invite.forEach(invitation -> {
//      System.out.println("Declared: " + invitation.checkInvite());
//      System.out.println("Username: " + invitation.userNameGet());
//      System.out.println("Code: " + invitation.inviteCodeGet());
//      System.out.println("Email: " + invitation.emailGet());
//      System.out.println("Roles: " + invitation.rolesGet());
//      System.out.println();
//    });
//  }
//
//  // Retrieve a password reset request by email
//  public ResetPasswordController accessEmailAsk(String email) {
//    return reset.stream()
//      .filter(request -> request.getEmail().equals(email))
//      .findFirst()
//      .orElse(null);
//  }
//
//  // Update a user's password by their email
//  public boolean newUserUpdate(String email, String newPassword) {
//    User user = controlUser.stream()
//      .filter(u -> u.getEmail().equals(email))
//      .findFirst()
//      .orElse(null);
//    if (user != null) {
//      user.setPassword(newPassword);
//      return true;
//    }
//    return false;
//  }
//
//  // Remove a password reset request
//  public void discard(ResetPasswordController request) {
//    reset.remove(request);
//  }
//
//  // Generate a random one-time password
//  private String makePass() {
//    return String.valueOf(new Random().nextInt(1000000));
//  }
//
//  // Check if an email already exists in the controlUser list
//  public boolean emailNotEmpty(String email) {
//    return controlUser.stream()
//      .anyMatch(user -> user.getEmail() != null && user.getEmail().equalsIgnoreCase(email));
//  }
//}

package application;

import java.time.temporal.ChronoUnit;
import java.time.Instant;
import java.util.*;
import application_phase2.HelpSystem;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashSet;
import java.io.File;
import java.util.stream.Collectors;

public class UserAccessControl {
    // List to store password reset requests
    private List<ResetPasswordController> reset;

    // List to store sent invites
    private List<Invite> invite;

    // List to store all registered users
    private List<User> controlUser;

    // Reference to the HelpSystem instance
    private HelpSystem helpSystem;
    
    // Default constructor (no-argument)
    public UserAccessControl() {
        // Initialize fields if needed
        System.out.println("UserAccessControl initialized without HelpSystem.");
    }

    // Constructor initializing empty lists and accepting HelpSystem
    public UserAccessControl(HelpSystem helpSystem) {
        this.reset = new ArrayList<>();
        this.controlUser = new ArrayList<>();
        this.invite = new ArrayList<>();
        this.helpSystem = helpSystem;
    }
    
    // Getter for HelpSystem
    public HelpSystem getHelpSystem() {
        return helpSystem;
    }
    
    // Finalize user setup by setting user details and marking setup as complete
    public boolean finalize(User user, String firstName, String middleName, String lastName,
                            String preferredName, String email) {
        user.setEmail(email);
        user.setFirstName(firstName);
        user.setMiddleName(middleName);
        user.setLastName(lastName);
        user.setPreferredName(preferredName);
        user.completedSetup(true); // Mark setup as complete
        return true;
    }

    // Create and add a new user to the controlUser list
    public User implementUser(String username, String password, Set<Role> roles) {
        User newUser = new User(username, password, roles);
        controlUser.add(newUser);
        return newUser;
    }

    // Check if a user with the given username and password exists in controlUser
    public User implementChecker(String username, String password) {
        return controlUser.stream()
            .filter(user -> user.getUsername().equals(username) && user.getPassword().equals(password))
            .findFirst()
            .orElse(null);
    }

    // Create an admin user if no users exist
    public User hashUser(String username, String password) {
        if (controlUser.isEmpty()) {
            User admin = new User(username, password, new HashSet<>(Collections.singletonList(Role.ADMIN)));
            controlUser.add(admin);
            return admin;
        }
        return null;
    }

    // Find and return a user by their username
    public User locateUser(String username) {
        return controlUser.stream()
            .filter(user -> user.getUsername().equals(username))
            .findFirst()
            .orElse(null);
    }

    // Print details of all users in the controlUser list
    public void listUsers() {
        controlUser.forEach(user -> {
            System.out.println("Username: " + user.getUsername());
            System.out.println("Name: " + user.getFirstName() + " " + user.getLastName());
            System.out.println("Roles: " + user.getRoles());
            System.out.println("Setup Complete: " + user.detectCompleteSetup());
            System.out.println();
        });
    }

    // Return a list of all users
    public List<User> arrayUsers() {
        return new ArrayList<>(controlUser);
    }

    // Add a role to a user
    public void roleImplement(User user, Role role) {
        user.getRoles().add(role);
    }

    // Remove a role from a user
    public void roleRemove(User user, Role role) {
        user.getRoles().remove(role);
    }

    // Remove a user from the controlUser list
    public boolean userDelete(User user) {
        return controlUser.remove(user);
    }

    // Create and send an invitation to a user, returning the invite code
    public String userInvitation(String username, String email, Set<Role> roles) {
        Invite inviteNew = new Invite(username, email, roles);
        invite.add(inviteNew);
        System.out.println("Code: " + inviteNew.inviteCodeGet());
        return inviteNew.inviteCodeGet();
    }

    // Check if an invitation code is valid and not yet used
    public boolean checkUserInvite(String invitationCode) {
        return invite.stream()
            .anyMatch(invitation -> invitation.inviteCodeGet().equals(invitationCode) && !invitation.checkInvite());
    }

    // Retrieve an invite by its code
    public Invite invitecodeGetinvite(String invitationCode) {
        return invite.stream()
            .filter(invitation -> invitation.inviteCodeGet().equals(invitationCode))
            .findFirst()
            .orElse(null);
    }

    // Request a password reset and generate a one-time password
    public void passwordResetAsk(String email) {
        String oneTimePassword = makePass();
        Instant expirationTime = Instant.now().plus(3, ChronoUnit.DAYS); // Set expiration in 3 days
        System.out.println(email + "'s one time password is " + oneTimePassword + " Expiration:" + expirationTime);
        reset.add(new ResetPasswordController(email, oneTimePassword, expirationTime));
    }

    // Delete an invitation by its code
    public void deleteUserInvite(String invitationCode) {
        invite.removeIf(invitation -> invitation.inviteCodeGet().equals(invitationCode));
    }

    // Print details of all invitations
    public void inviteLists() {
        invite.forEach(invitation -> {
            System.out.println("Declared: " + invitation.checkInvite());
            System.out.println("Username: " + invitation.userNameGet());
            System.out.println("Code: " + invitation.inviteCodeGet());
            System.out.println("Email: " + invitation.emailGet());
            System.out.println("Roles: " + invitation.rolesGet());
            System.out.println();
        });
    }

    // Retrieve a password reset request by email
    public ResetPasswordController accessEmailAsk(String email) {
        return reset.stream()
            .filter(request -> request.getEmail().equals(email))
            .findFirst()
            .orElse(null);
    }

    // Update a user's password by their email
    public boolean newUserUpdate(String email, String newPassword) {
        User user = controlUser.stream()
            .filter(u -> u.getEmail().equals(email))
            .findFirst()
            .orElse(null);
        if (user != null) {
            user.setPassword(newPassword);
            return true;
        }
        return false;
    }

    // Remove a password reset request
    public void discard(ResetPasswordController request) {
        reset.remove(request);
    }

    // Generate a random one-time password
    private String makePass() {
        return String.valueOf(new Random().nextInt(1000000));
    }

    // Check if an email already exists in the controlUser list
    public boolean emailNotEmpty(String email) {
        return controlUser.stream()
            .anyMatch(user -> user.getEmail() != null && user.getEmail().equalsIgnoreCase(email));
    }
    
    //remember user
 // Save users to a file
    public void saveUsersToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("users.txt"))) {
            for (User user : controlUser) {
                // Serialize user data as "username:password:email:firstName:middleName:lastName:preferredName:roles:setup"
                String rolesString = String.join(",", user.getRoles().stream().map(Role::name).toList());
                writer.println(user.getUsername() + ":" + user.getPassword() + ":" + 
                               user.getEmail() + ":" + user.getFirstName() + ":" +
                               user.getMiddleName() + ":" + user.getLastName() + ":" +
                               user.getPreferredName() + ":" + rolesString + ":" +
                               user.detectCompleteSetup());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    //load user
 // Load users from a file
    public void loadUsersFromFile() {
        File file = new File("users.txt");
        try {
            // Create the file if it doesn't exist
            if (!file.exists()) {
                file.createNewFile();
            }

            // Proceed with reading the file
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length >= 9) { // Ensure all fields are present
                    String username = parts[0];
                    String password = parts[1];
                    String email = parts[2];
                    String firstName = parts[3];
                    String middleName = parts[4];
                    String lastName = parts[5];
                    String preferredName = parts[6];
                    Set<Role> roles = Arrays.stream(parts[7].split(","))
                                            .map(Role::valueOf)
                                            .collect(Collectors.toSet());
                    boolean setup = Boolean.parseBoolean(parts[8]);

                    // Reconstruct the User object
                    User user = new User(username, password, roles);
                    user.setEmail(email);
                    user.setFirstName(firstName);
                    user.setMiddleName(middleName);
                    user.setLastName(lastName);
                    user.setPreferredName(preferredName);
                    user.completedSetup(setup);

                    // Add the user to the controlUser list
                    controlUser.add(user);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}

