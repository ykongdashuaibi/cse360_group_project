package application;

//import javafx.scene.Scene;
//import javafx.stage.Stage;
//
//public class LoginController {
//  private Stage mainStage;
//  private UserAccessControl UserAdminController;
//  // Constructor that initializes the main stage and user admin controller
//  public LoginController(Stage mainStage, UserAccessControl UserAdminController) {
//    this.mainStage = mainStage;
//    this.UserAdminController = UserAdminController;
//  }
//  // Method to trigger the appropriate login page based on user availability
//  public Scene triggerLoginPage() {
//    if (UserAdminController.arrayUsers().isEmpty()) {
//      return new SignUpPage(mainStage, UserAdminController).triggerAdminPage();
//    } else {
//      return new LoginPage(mainStage, UserAdminController).triggerLoginSelection();
//    }
//  }
//}
import javafx.scene.Scene;
import javafx.stage.Stage;
import application_phase2.HelpSystem;

public class LoginController {
    private Stage mainStage;
    private UserAccessControl userAdminController;
    private HelpSystem helpSystem; // Added HelpSystem reference

    // Constructor that initializes the main stage, user admin controller, and help system
    public LoginController(Stage mainStage, UserAccessControl userAdminController, HelpSystem helpSystem) {
        this.mainStage = mainStage;
        this.userAdminController = userAdminController;
        this.helpSystem = helpSystem;
    }

    // Method to trigger the appropriate login page based on user availability
    public Scene triggerLoginPage() {
        if (userAdminController.arrayUsers().isEmpty()) {
            return new SignUpPage(mainStage, userAdminController).triggerAdminPage();
        } else {
            // Pass helpSystem to LoginPage
            return new LoginPage(mainStage, userAdminController, helpSystem).triggerLoginSelection();
        }
    }
}
