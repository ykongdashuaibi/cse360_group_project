package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import application_phase2.HelpSystem;

import java.io.File;
import java.util.List;
import java.util.Optional;

import application_phase2.Article;
import application_phase2.ArticleDialog;
import application_phase2.ArticleListDialog;

import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.ComboBox;

/**
 * InstructorHomePage class provides the graphical user interface (GUI) for the instructor's homepage in the application.
 * It enables instructors to manage articles, perform backup and restore operations, and log out.
 * 
 * <p>Key functionalities include:
 * <ul>
 *     <li>Creating, updating, viewing, deleting, and listing articles</li>
 *     <li>Backing up and restoring articles, with optional group-specific backup</li>
 *     <li>Logging out</li>
 * </ul>
 * </p>
 * 
 * This class interacts with:
 * <ul>
 *     <li>UserAccessControl for managing user-related actions</li>
 *     <li>HelpSystem for article management and data backup operations</li>
 * </ul>
 * 
 * @see UserAccessControl
 * @see HelpSystem
 */
public class InstructorHomePage {
  private Stage mainStage;
  private UserAccessControl userAdminController;
  private HelpSystem helpSystem;

  /**
   * Constructor for initializing the InstructorHomePage with the main application stage and user control.
   * 
   * @param mainStage The main application stage to display the instructor page
   * @param userAdminController The controller for user-related actions
   */
  public InstructorHomePage(Stage mainStage, UserAccessControl userAdminController) {
    this.mainStage = mainStage;
    this.userAdminController = userAdminController;
    this.helpSystem = userAdminController.getHelpSystem();
  }

  /**
   * Sets up the main layout and elements for the instructor's homepage.
   * Initializes and arranges buttons for various article management and backup functionalities.
   * 
   * @return A Scene object representing the instructor's homepage
   */
  public Scene instructorHomePage() {
	    mainStage.setTitle("Instructor Home Page");

	    // Create GridPane for layout
	    GridPane gridPane = new GridPane();
	    gridPane.setAlignment(Pos.CENTER);
	    gridPane.setHgap(20); // Increase horizontal gap for better spacing
	    gridPane.setVgap(15); // Increase vertical gap for better spacing
	    gridPane.setPadding(new Insets(25, 25, 25, 25));

	    // Welcome label
	    Label welcome = new Label("Welcome");
	    welcome.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;"); // Style for welcome text
	    gridPane.add(welcome, 0, 0, 2, 1);

	    // Define buttons
	    Button createArticleButton = new Button("Create Article");
	    Button updateArticleButton = new Button("Update Article");
	    Button deleteArticleButton = new Button("Delete Article");
	    Button listArticlesButton = new Button("List Articles");
	    Button listArticlesGroupButton = new Button("List Articles with Group");
	    Button viewArticleButton = new Button("View Article");
	    Button backupButton = new Button("Backup");
	    Button restoreButton = new Button("Restore");
	    Button viewHelpMessagesButton = new Button("View Help Messages");
	    Button deleteHelpMessageButton = new Button("Delete Help Message");
	    Button addStudentToGroupButton = new Button("Add Student to Group");
	    Button viewStudentsInGroupButton = new Button("View Students in Group");
	    Button deleteStudentFromGroupButton = new Button("Delete Student from Group");
	    Button logoutButton = new Button("Logout");
	    
	    // Group management buttons
	    Button manageGroupButton = new Button("Manage Groups");
	    manageGroupButton.setOnAction(e -> manageGroup(false)); // False for general group
	    Button manageSpecialGroupButton = new Button("Manage Special Groups");
	    manageSpecialGroupButton.setOnAction(e -> manageGroup(true)); // True for special group

	    // Delete group buttons
	    Button deleteGroupButton = new Button("Delete Group");
	    deleteGroupButton.setOnAction(e -> deleteGroup(false)); // False for general group
	    Button deleteSpecialGroupButton = new Button("Delete Special Group");
	    deleteSpecialGroupButton.setOnAction(e -> deleteGroup(true)); // True for special group

	 // Add buttons to GridPane with proper positioning
	    gridPane.add(createArticleButton, 0, 1);
	    gridPane.add(updateArticleButton, 1, 1);
	    gridPane.add(viewArticleButton, 0, 2);
	    gridPane.add(deleteArticleButton, 1, 2);
	    gridPane.add(listArticlesButton, 0, 3);
	    gridPane.add(listArticlesGroupButton, 1, 3);
	    gridPane.add(backupButton, 0, 4);
	    gridPane.add(restoreButton, 1, 4);
	    gridPane.add(viewHelpMessagesButton, 0, 5);
	    gridPane.add(deleteHelpMessageButton, 1, 5);
	    gridPane.add(manageGroupButton, 0, 6); // Add manage group button
	    gridPane.add(manageSpecialGroupButton, 1, 6); // Add manage special group button
	    gridPane.add(addStudentToGroupButton, 0, 7);
	    gridPane.add(viewStudentsInGroupButton, 1, 7);
	    gridPane.add(deleteStudentFromGroupButton, 0, 8);
	    gridPane.add(deleteGroupButton, 1, 8); // Add delete group button
	    gridPane.add(deleteSpecialGroupButton, 0, 9); // Add delete special group button
	    gridPane.add(logoutButton, 0, 10, 2, 1); // Adjusted to fit the sequence


	    // Assign actions to buttons (placeholders for existing implementations)
	    createArticleButton.setOnAction(e -> showArticleDialog(null));
	    updateArticleButton.setOnAction(e -> showUpdateArticleDialog());
	    deleteArticleButton.setOnAction(e -> showDeleteArticleDialog());
	    listArticlesButton.setOnAction(e -> showArticleList());
	    listArticlesGroupButton.setOnAction(e -> handleListArticlesByGroup());
	    viewArticleButton.setOnAction(e -> handleViewArticle());
	    backupButton.setOnAction(e -> handleBackup());
	    restoreButton.setOnAction(e -> handleRestore());
	    viewHelpMessagesButton.setOnAction(e -> viewHelpMessages());
	    deleteHelpMessageButton.setOnAction(e -> deleteHelpMessage());
	    viewStudentsInGroupButton.setOnAction(e -> viewStudentsInGroup());
	    deleteStudentFromGroupButton.setOnAction(e -> deleteStudentFromGroup());
	    manageGroupButton.setOnAction(e -> manageGroup(false)); // False for general group
	    manageSpecialGroupButton.setOnAction(e -> manageGroup(true)); // True for special group
	    deleteGroupButton.setOnAction(e -> deleteGroup(false)); // False for general group
	    deleteSpecialGroupButton.setOnAction(e -> deleteGroup(true)); // True for special group
	    logoutButton.setOnAction(e -> triggerLogout());

	    addStudentToGroupButton.setOnAction(e -> {
	        TextInputDialog userInputDialog = new TextInputDialog();
	        userInputDialog.setTitle("Add Student to Group");
	        userInputDialog.setHeaderText("Enter Student Username and Group Name");
	        userInputDialog.setContentText("Format: username,group");

	        Optional<String> input = userInputDialog.showAndWait();
	        input.ifPresent(data -> {
	            String[] parts = data.split(",");
	            if (parts.length == 2) {
	                String username = parts[0].trim();
	                String groupName = parts[1].trim();
	                boolean success = helpSystem.addStudentToGroup(username, groupName);
	                showMessage(success ? "Student added to group successfully." : "Failed to add student to group.");
	            } else {
	                showMessage("Invalid input format. Use: username,group");
	            }
	        });
	    });

	    // Return the updated Scene
	    return new Scene(gridPane, 500, 600); // Adjust scene dimensions to fit the layout
	}
 
  /**
   * Displays a dialog for performing a backup of articles.
   * Allows instructors to specify a group for the backup or leave it blank to back up all articles.
   */
  private void handleBackup() {
	    TextInputDialog groupInputDialog = new TextInputDialog();
	    groupInputDialog.setTitle("Backup Group");
	    groupInputDialog.setHeaderText("Enter Group Name (leave empty to backup all articles)");
	    groupInputDialog.setContentText("Group:");

	    Optional<String> groupResult = groupInputDialog.showAndWait();
	    groupResult.ifPresent(group -> {
	        FileChooser fileChooser = new FileChooser();
	        fileChooser.setTitle("Save Backup File");
	        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Backup Files", "*.dat"));
	        File file = fileChooser.showSaveDialog(mainStage);

	        if (file != null) {
	            helpSystem.backupArticlesByGroup(file.getAbsolutePath(), group.trim());
	        }
	    });
	}

  /**
   * Prompts the instructor to enter a group name and displays a list of articles belonging to that group.
   * If no articles are found, an alert is shown.
   */
  private void handleListArticlesByGroup() {
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Enter Group Name");
	    dialog.setHeaderText("List Articles by Group");
	    dialog.setContentText("Please enter the group name:");

	    Optional<String> result = dialog.showAndWait();
	    result.ifPresent(groupName -> {
	        List<Article> articlesInGroup = helpSystem.getArticlesByGroup(groupName);
	        if (articlesInGroup.isEmpty()) {
	            showAlert("No Articles Found", "No articles found for group: " + groupName);
	        } else {
	            displayArticlesInGroup(articlesInGroup);
	        }
	    });
	}
  
  /**
   * Displays a list of articles in a new window based on the provided group.
   * Shows a table with columns for article ID and title.
   * 
   * @param articles The list of articles to display
   */
  private void displayArticlesInGroup(List<Article> articles) {
	    Stage groupStage = new Stage();
	    groupStage.setTitle("Articles in Group");

	    TableView<Article> articleTable = new TableView<>();
	    articleTable.setItems(FXCollections.observableArrayList(articles));

	    TableColumn<Article, Long> idColumn = new TableColumn<>("ID");
	    idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

	    TableColumn<Article, String> titleColumn = new TableColumn<>("Title");
	    titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

	    articleTable.getColumns().addAll(idColumn, titleColumn);

	    VBox vbox = new VBox(articleTable);
	    Scene scene = new Scene(vbox);
	    groupStage.setScene(scene);
	    groupStage.show();
	}

  /**
   * Displays a dialog for restoring articles from a backup file.
   * Provides options to either clear existing articles or merge with the current articles.
   */
  private void handleRestore() {
      FileChooser fileChooser = new FileChooser();
      fileChooser.setTitle("Select Backup File");
      fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Backup Files", "*.dat"));
      File file = fileChooser.showOpenDialog(mainStage);

      if (file != null) {
          ChoiceDialog<String> dialog = new ChoiceDialog<>("Clear existing articles", "Clear existing articles", "Merge with current articles");
          dialog.setTitle("Restore Options");
          dialog.setHeaderText("Choose Restore Option");
          dialog.setContentText("Select action:");

          Optional<String> result = dialog.showAndWait();
          result.ifPresent(choice -> {
              boolean clearCurrent = choice.equals("Clear existing articles");
              helpSystem.restoreArticles(file.getAbsolutePath(), clearCurrent);
          });
      }
  }

  /**
   * Opens a dialog for creating or updating an article.
   * If an article is provided, the dialog is populated for editing.
   * 
   * @param article The article to edit, or null if creating a new article
   */
  private void showArticleDialog(Article article) {
    ArticleDialog dialog = new ArticleDialog(mainStage, helpSystem, article);
    dialog.showAndWait();
  }

  /**
   * Prompts the instructor to enter an article ID to update.
   * Searches for the article and opens the article dialog for editing if found.
   */
  private void showUpdateArticleDialog() {
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Update Article");
	    dialog.setHeaderText("Enter the ID of the article you want to update:");
	    dialog.setContentText("Article ID:");

	    Optional<String> result = dialog.showAndWait();

	    result.ifPresent(idStr -> {
	        try {
	            long articleId = Long.parseLong(idStr); // Parse the article ID from the dialog input
	            System.out.println("Searching for article with ID: " + articleId); // Debug

	            Article selectedArticle = helpSystem.findArticleById(articleId);

	            if (selectedArticle != null) {
	                System.out.println("Article found. Opening update dialog."); // Debug
	                showArticleDialog(selectedArticle); // Pass selected article for updating
	            } else {
	                System.out.println("Article not found for updating.");
	                showAlert("Error", "Article with ID " + articleId + " not found.");
	            }
	        } catch (NumberFormatException e) {
	            System.out.println("Invalid input. Please enter a valid numeric article ID.");
	            showAlert("Input Error", "Please enter a valid numeric article ID.");
	        }
	    });
	}

  /**
   * Prompts the instructor to enter an article ID to view.
   * Displays the article details if found.
   */
  private void handleViewArticle() {
	    // Prompt user for Article ID
	    TextInputDialog idInputDialog = new TextInputDialog();
	    idInputDialog.setTitle("View Article");
	    idInputDialog.setHeaderText("Enter the ID of the article you want to view");
	    idInputDialog.setContentText("Article ID:");

	    Optional<String> result = idInputDialog.showAndWait();
	    result.ifPresent(idString -> {
	        try {
	            long articleId = Long.parseLong(idString.trim());
	            Article article = helpSystem.findArticleById(articleId);

	            if (article != null) {
	                displayArticle(article);
	            } else {
	                showAlert("Error", "No article found with ID: " + articleId);
	            }
	        } catch (NumberFormatException ex) {
	            showAlert("Error", "Invalid ID format. Please enter a numeric ID.");
	        }
	    });
	}

  /**
   * Displays the details of an article in a separate stage.
   * Sets up a form view of the article fields (title, level, description, etc.).
   * 
   * @param article The article to display
   */
	private void displayArticle(Article article) {
	    Stage articleStage = new Stage();
	    articleStage.setTitle("Article Details");

	    // Layout for displaying article details
	    GridPane articleLayout = new GridPane();
	    articleLayout.setPadding(new Insets(10));
	    articleLayout.setVgap(10);
	    articleLayout.setHgap(10);
	    articleLayout.setAlignment(Pos.CENTER_LEFT);

	    articleLayout.add(new Label("Title:"), 0, 0);
	    articleLayout.add(new TextField(article.getTitle()), 1, 0);
	    
	    articleLayout.add(new Label("Level:"), 0, 1);
	    articleLayout.add(new TextField(article.getLevel()), 1, 1);
	    
	    articleLayout.add(new Label("Short Description:"), 0, 2);
	    articleLayout.add(new TextField(article.getShortDescription()), 1, 2);
	    
	    articleLayout.add(new Label("Keywords:"), 0, 3);
	    articleLayout.add(new TextField(article.getKeywords()), 1, 3);
	    
	    articleLayout.add(new Label("Body:"), 0, 4);
	    TextArea bodyText = new TextArea(article.getBody());
	    bodyText.setWrapText(true);
	    bodyText.setPrefHeight(100);
	    articleLayout.add(bodyText, 1, 4);
	    
	    articleLayout.add(new Label("References:"), 0, 5);
	    articleLayout.add(new TextField(article.getReferences()), 1, 5);
	    
	    articleLayout.add(new Label("Groups:"), 0, 6);
	    articleLayout.add(new TextField(String.join(", ", article.getGroups())), 1, 6);

	    // Back button to close the window
	    Button backButton = new Button("Back");
	    backButton.setOnAction(e -> articleStage.close());
	    articleLayout.add(backButton, 1, 7);

	    Scene scene = new Scene(articleLayout, 600, 500);
	    articleStage.setScene(scene);
	    articleStage.show();
	}
  
	/**
     * Displays an alert dialog with the provided title and message.
     * Used for error notifications and informational messages.
     * 
     * @param title The title of the alert dialog
     * @param message The message content of the alert dialog
     */
	private void showAlert(String title, String message) {
	    Alert alert = new Alert(Alert.AlertType.ERROR);
	    alert.setTitle(title);
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.showAndWait();
	}

	 /**
     * Prompts the instructor to enter an article ID to delete.
     * Attempts to delete the article from the HelpSystem if it exists.
     */
	private void showDeleteArticleDialog() {
		    // Create a dialog for entering the article ID to delete
		    TextInputDialog dialog = new TextInputDialog();
		    dialog.setTitle("Delete Article by ID");
		    dialog.setHeaderText("Delete Article by ID");
		    dialog.setContentText("Please enter the ID of the article you want to delete:");
	
		    // Show the dialog and capture the result
		    Optional<String> result = dialog.showAndWait();
	
		    // If the user provided an ID, attempt to delete the article
		    result.ifPresent(idStr -> {
		        try {
		            long id = Long.parseLong(idStr); // Parse the ID input as a long
		            boolean deleted = helpSystem.deleteArticle(id); // Try to delete the article
	
		            // Notify the user about the deletion result
		            if (deleted) {
		                System.out.println("Article with ID " + id + " was successfully deleted.");
		            } else {
		                System.out.println("Article with ID " + id + " not found.");
		            }
		        } catch (NumberFormatException e) {
		            System.out.println("Invalid ID format. Please enter a numeric ID.");
		        }
		    });
		}

	 /**
     * Retrieves and prints a list of all articles in the system to the console.
     * Outputs detailed information about each article.
     */
	  private void listArticles() {
		    List<Article> articles = helpSystem.getAllArticles(); // Assuming getAllArticles() returns a list of articles
	
		    if (articles.isEmpty()) {
		        System.out.println("No articles found.");
		    } else {
		        System.out.println("Articles List:");
		        for (Article article : articles) {
		            System.out.println("ID: " + article.getId());
		            System.out.println("Title: " + article.getTitle());
		            System.out.println("Level: " + article.getLevel());
		            System.out.println("Short Description: " + article.getShortDescription());
		            System.out.println("Keywords: " + article.getKeywords());
		            System.out.println("Body: " + article.getBody());
		            System.out.println("References: " + article.getReferences());
		            System.out.println("Groups: " + article.getGroups());
		            System.out.println("--------------------------------------------------");
		        }
		    }
		}
 
	  /**
	     * Retrieves and displays a list of all articles in the system.
	     * Uses an ArticleListDialog to present the articles in a tabular view.
	     */
	  private void showArticleList() {
		    // Retrieve articles from HelpSystem
		    ObservableList<Article> articles = FXCollections.observableArrayList(helpSystem.getAllArticles());
		    
		    // Create and display the ArticleListDialog with the list of articles
		    ArticleListDialog articleListDialog = new ArticleListDialog(mainStage, articles);
		    articleListDialog.showAndWait();
		}

	  /**
	     * Logs out the instructor and returns to the login page.
	     * Reinitializes the login controller and switches the main stage to the login scene.
	     */	  
	  private void triggerLogout() {
		    LoginController loginController = new LoginController(mainStage, userAdminController, helpSystem);
		    mainStage.setScene(loginController.triggerLoginPage());
		}

	  
	  //phase 4 code
	  private void showMessage(String message) {
		    Alert alert = new Alert(Alert.AlertType.INFORMATION);
		    alert.setTitle("Information");
		    alert.setHeaderText(null);
		    alert.setContentText(message);
		    alert.showAndWait();
		}

	  private void viewHelpMessages() {
		    List<String> messages = helpSystem.getAllMessages(); // Retrieve messages from HelpSystem

		    if (messages.isEmpty()) {
		        showMessage("No messages available.");
		        return;
		    }

		    // Build a display string
		    StringBuilder messageDisplay = new StringBuilder("Help System Messages:\n\n");
		    for (int i = 0; i < messages.size(); i++) {
		        messageDisplay.append((i + 1)).append(". ").append(messages.get(i)).append("\n\n");
		    }

		    // Display in a scrollable dialog
		    Alert alert = new Alert(Alert.AlertType.INFORMATION);
		    alert.setTitle("Help Messages");
		    alert.setHeaderText("Messages from Students:");
		    TextArea textArea = new TextArea(messageDisplay.toString());
		    textArea.setWrapText(true);
		    textArea.setEditable(false);
		    textArea.setPrefSize(500, 400);
		    alert.getDialogPane().setContent(textArea);
		    alert.showAndWait();
		}

	  private void deleteHelpMessage() {
		    List<String> messages = helpSystem.getAllMessages(); // Retrieve messages

		    if (messages.isEmpty()) {
		        showMessage("No messages available to delete.");
		        return;
		    }

		    // Build a display string for the messages
		    StringBuilder messageDisplay = new StringBuilder("Help System Messages:\n\n");
		    for (int i = 0; i < messages.size(); i++) {
		        messageDisplay.append((i + 1)).append(". ").append(messages.get(i)).append("\n\n");
		    }

		    // Show messages in a dialog
		    TextInputDialog dialog = new TextInputDialog();
		    dialog.setTitle("Delete Help Message");
		    dialog.setHeaderText("Help Messages:");
		    dialog.setContentText("Enter the sequence number of the message to delete:\n\n" + messageDisplay);

		    // Get the input from the instructor
		    Optional<String> result = dialog.showAndWait();
		    result.ifPresent(input -> {
		        try {
		            int sequenceNumber = Integer.parseInt(input.trim());
		            boolean deleted = helpSystem.deleteMessage(sequenceNumber);

		            if (deleted) {
		                showMessage("Message " + sequenceNumber + " deleted successfully.");
		            } else {
		                showMessage("Invalid sequence number. Please try again.");
		            }
		        } catch (NumberFormatException e) {
		            showMessage("Invalid input. Please enter a numeric sequence number.");
		        }
		    });
		}

	  private void searchHelpArticles() {
		    TextInputDialog searchDialog = new TextInputDialog();
		    searchDialog.setTitle("Search Help Articles");
		    searchDialog.setHeaderText("Search for Articles");
		    searchDialog.setContentText("Enter Search Query:");

		    Optional<String> queryResult = searchDialog.showAndWait();

		    queryResult.ifPresent(searchQuery -> {
		        ComboBox<String> groupComboBox = new ComboBox<>(FXCollections.observableArrayList(helpSystem.getAllGroups()));
		        groupComboBox.setPromptText("Select Group (Optional)");

		        ComboBox<String> levelComboBox = new ComboBox<>(FXCollections.observableArrayList("All", "Beginner", "Intermediate", "Advanced", "Expert"));
		        levelComboBox.setValue("All");

		        Alert searchAlert = new Alert(Alert.AlertType.INFORMATION);
		        searchAlert.setTitle("Filter Search");
		        searchAlert.setHeaderText("Filter by Group and Level");

		        GridPane filterPane = new GridPane();
		        filterPane.setHgap(10);
		        filterPane.setVgap(10);
		        filterPane.add(new Label("Group:"), 0, 0);
		        filterPane.add(groupComboBox, 1, 0);
		        filterPane.add(new Label("Level:"), 0, 1);
		        filterPane.add(levelComboBox, 1, 1);

		        searchAlert.getDialogPane().setContent(filterPane);
		        searchAlert.showAndWait();

		        String group = groupComboBox.getValue();
		        String level = levelComboBox.getValue();

		        List<Article> results = helpSystem.searchArticles(searchQuery, level, group);
		        if (results.isEmpty()) {
		            showMessage("No articles found.");
		        } else {
		            displaySearchResults(results);
		        }
		    });
		}

	  private void displaySearchResults(List<Article> results) {
		    StringBuilder resultDisplay = new StringBuilder("Search Results:\n\n");
		    for (int i = 0; i < results.size(); i++) {
		        Article article = results.get(i);
		        resultDisplay.append((i + 1))
		            .append(". Title: ").append(article.getTitle())
		            .append(" | ID: ").append(article.getId())
		            .append(" | Abstract: ").append(article.getShortDescription())
		            .append("\n");
		    }

		    Alert resultAlert = new Alert(Alert.AlertType.INFORMATION);
		    resultAlert.setTitle("Search Results");
		    resultAlert.setHeaderText("Articles Matching Your Search");
		    TextArea resultArea = new TextArea(resultDisplay.toString());
		    resultArea.setEditable(false);
		    resultArea.setWrapText(true);
		    resultAlert.getDialogPane().setContent(resultArea);

		    resultAlert.showAndWait();

		    TextInputDialog idDialog = new TextInputDialog();
		    idDialog.setTitle("View Article Details");
		    idDialog.setHeaderText("Enter the sequence number to view details:");
		    idDialog.setContentText("Sequence Number:");

		    Optional<String> result = idDialog.showAndWait();
		    result.ifPresent(sequence -> {
		        try {
		            int index = Integer.parseInt(sequence) - 1;
		            if (index >= 0 && index < results.size()) {
		                displayArticle(results.get(index));
		            } else {
		                showMessage("Invalid sequence number.");
		            }
		        } catch (NumberFormatException e) {
		            showMessage("Please enter a valid number.");
		        }
		    });
		}

	  private void manageGroup(boolean isSpecialGroup) {
		    TextInputDialog groupDialog = new TextInputDialog();
		    groupDialog.setTitle(isSpecialGroup ? "Special Group Management" : "General Group Management");
		    groupDialog.setHeaderText(isSpecialGroup ? "Create/Edit Special Access Group" : "Create/Edit General Group");
		    groupDialog.setContentText("Enter Group Name:");

		    Optional<String> groupResult = groupDialog.showAndWait();
		    groupResult.ifPresent(groupName -> {
		        boolean success = isSpecialGroup ? helpSystem.addSpecialGroup(groupName) : helpSystem.addGeneralGroup(groupName);
		        if (success) {
		            showMessage("Group added/updated successfully.");
		        } else {
		            showMessage("Failed to add/update the group.");
		        }
		    });
		}

	  private void deleteGroup(boolean isSpecialGroup) {
		    // Create a ComboBox to select a group to delete
		    ComboBox<String> groupComboBox = new ComboBox<>(
		        FXCollections.observableArrayList(
		            isSpecialGroup ? helpSystem.getSpecialGroups() : helpSystem.getGeneralGroups()
		        )
		    );
		    groupComboBox.setPromptText("Select Group to Delete");

		    // Create an alert for deletion
		    Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
		    deleteAlert.setTitle("Delete Group");
		    deleteAlert.setHeaderText(isSpecialGroup ? "Delete Special Access Group" : "Delete General Group");
		    deleteAlert.getDialogPane().setContent(groupComboBox);
		    deleteAlert.showAndWait();

		    // Get the selected group and perform deletion
		    String selectedGroup = groupComboBox.getValue();
		    if (selectedGroup != null) {
		        boolean success = isSpecialGroup
		            ? helpSystem.deleteSpecialGroup(selectedGroup)
		            : helpSystem.deleteGeneralGroup(selectedGroup);

		        showMessage(success ? "Group deleted successfully." : "Failed to delete the group.");
		    }
		}


	  private void addStudentToGroup() {
		    TextInputDialog userInputDialog = new TextInputDialog();
		    userInputDialog.setTitle("Add Student to Group");
		    userInputDialog.setHeaderText("Enter Student Username and Group Name");
		    userInputDialog.setContentText("Format: username,group");

		    Optional<String> input = userInputDialog.showAndWait();
		    input.ifPresent(data -> {
		        String[] parts = data.split(",");
		        if (parts.length == 2) {
		            boolean success = helpSystem.addStudentToGroup(parts[0].trim(), parts[1].trim());
		            showMessage(success ? "Student added to group successfully." : "Failed to add student to group.");
		        } else {
		            showMessage("Invalid input format. Use: username,group");
		        }
		    });
		}


	  private void viewStudentsInGroup() {
		    TextInputDialog groupInputDialog = new TextInputDialog();
		    groupInputDialog.setTitle("View Students in Group");
		    groupInputDialog.setHeaderText("Enter Group Name:");
		    groupInputDialog.setContentText("Group:");

		    Optional<String> groupResult = groupInputDialog.showAndWait();
		    groupResult.ifPresent(group -> {
		        List<String> students = helpSystem.getStudentsInGroup(group.trim());
		        if (students.isEmpty()) {
		            showMessage("No students found in the group.");
		        } else {
		            StringBuilder studentList = new StringBuilder("Students in Group:\n");
		            for (String student : students) {
		                studentList.append("- ").append(student).append("\n");
		            }
		            showMessage(studentList.toString());
		        }
		    });
		}


	  private void deleteStudentFromGroup() {
		    TextInputDialog inputDialog = new TextInputDialog();
		    inputDialog.setTitle("Delete Student from Group");
		    inputDialog.setHeaderText("Enter Student Username and Group Name");
		    inputDialog.setContentText("Format: username,group");

		    Optional<String> input = inputDialog.showAndWait();
		    input.ifPresent(data -> {
		        String[] parts = data.split(",");
		        if (parts.length == 2) {
		            boolean success = helpSystem.removeStudentFromGroup(parts[0].trim(), parts[1].trim());
		            showMessage(success ? "Student removed from group successfully."
		                                : "Failed to remove student from group.");
		        } else {
		            showMessage("Invalid input format. Use: username,group");
		        }
		    });
		}

}

