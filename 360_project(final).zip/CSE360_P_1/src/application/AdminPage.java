package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import application_phase2.HelpSystem;
import application_phase2.Article;
import application_phase2.ArticleDialog;
import application_phase2.ArticleListDialog;
import java.util.Scanner;
import javafx.scene.control.TextInputDialog;
import java.util.Optional;
import java.util.List;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.stage.FileChooser;
import java.io.File;
import javafx.scene.control.ChoiceDialog;
import java.util.InputMismatchException;
import javafx.scene.control.Alert;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;

/**
 * AdminPage class provides the graphical user interface (GUI) for the administrator's homepage in the application.
 * It allows the admin to manage articles, users, backups, and system configurations.
 * 
 * <p>Key functionalities include:
 * <ul>
 *     <li>Creating, updating, viewing, deleting, and listing articles</li>
 *     <li>Managing user accounts (inviting, resetting passwords, deleting, listing)</li>
 *     <li>Backing up and restoring articles, with an option for group-specific backups</li>
 *     <li>Handling logout functionality</li>
 * </ul>
 * </p>
 * 
 * <p>This class interacts with:
 * <ul>
 *     <li>UserAccessControl for user management operations</li>
 *     <li>HelpSystem for article and data backup operations</li>
 * </ul>
 * </p>
 * 
 * @see UserAccessControl
 * @see HelpSystem
 */
public class AdminPage {
  private Stage mainStage;
  private UserAccessControl userAdminController;
  private HelpSystem helpSystem;

  /**
   * Constructor for initializing the AdminPage with main application stage and user control.
   * 
   * @param mainStage The main application stage to display the admin page
   * @param userAdminController The controller for user management
   */
  public AdminPage(Stage mainStage, UserAccessControl userAdminController) {
    this.mainStage = mainStage;
    this.userAdminController = userAdminController;
    this.helpSystem = userAdminController.getHelpSystem(); // Assuming UserAccessControl has access to HelpSystem
  }

  /**
   * Sets up the main layout and elements for the admin homepage.
   * Initializes and arranges buttons for various functionalities.
   * 
   * @return A Scene object representing the admin homepage
   */
  public Scene adminHomePage() {
    mainStage.setTitle("Admin Page");

    GridPane homeGrid = new GridPane();
    homeGrid.setAlignment(Pos.CENTER);
    homeGrid.setHgap(10);
    homeGrid.setVgap(15);
    homeGrid.setPadding(new Insets(25, 25, 25, 25));

    // CRUD buttons for articles
    Button createArticleButton = new Button("Create Article");
    Button updateArticleButton = new Button("Update Article");
    Button deleteArticleButton = new Button("Delete Article");
    Button listArticlesButton = new Button("List Articles");
    Button listArticlesGroupButton = new Button("List Articles with group");
    Button showArticlesButton = new Button("View Article");
    Button backupButton = new Button("Backup");
    Button restoreButton = new Button("Restore");
    
    // Create buttons for user management
    Button inviteButton = new Button("Invite");
    Button passwordResetButton = new Button("Password Reset");
    Button deleteAccountButton = new Button("Delete an Account");
    Button listUsersButton = new Button("List All Users");
    Button logoutButton = new Button("Logout");
    //Button logout = new Button("Logout");
    
    //button for help message
    Button viewHelpMessagesButton = new Button("View Help Messages");
    Button deleteHelpMessageButton = new Button("Delete Help Message");
    
 // New Buttons for Group and User Management
    Button addUserToGroupButton = new Button("Add User to Group");
    Button viewGroupUsersButton = new Button("View Users in Group");
    Button removeUserFromGroupButton = new Button("Remove User from Group");
    Button manageGeneralGroupsButton = new Button("Manage General Groups");
    Button manageSpecialGroupsButton = new Button("Manage Special Groups");


 // Existing buttons for articles
    homeGrid.add(createArticleButton, 0, 1);
    homeGrid.add(updateArticleButton, 1, 1);

    homeGrid.add(showArticlesButton, 0, 2);
    homeGrid.add(deleteArticleButton, 1, 2);

    homeGrid.add(listArticlesButton, 0, 3);
    homeGrid.add(listArticlesGroupButton, 1, 3);

    homeGrid.add(backupButton, 0, 4);
    homeGrid.add(restoreButton, 1, 4);

    // Phase 1 buttons for user management
    homeGrid.add(inviteButton, 0, 6);
    homeGrid.add(passwordResetButton, 1, 6);
    homeGrid.add(listUsersButton, 0, 7);
    homeGrid.add(deleteAccountButton, 1, 7);

    // Buttons for help messages
    homeGrid.add(viewHelpMessagesButton, 0, 8);
    homeGrid.add(deleteHelpMessageButton, 1, 8);

    // Logout button centered across both columns
    homeGrid.add(logoutButton, 0, 12, 2, 1);

    // New buttons for group and user management
    homeGrid.add(addUserToGroupButton, 0, 9);         // Add User to Group
    homeGrid.add(viewGroupUsersButton, 1, 9);        // View Users in Group
    homeGrid.add(removeUserFromGroupButton, 0, 10);   // Remove User from Group
    homeGrid.add(manageGeneralGroupsButton, 1, 10);   // Manage General Groups
    homeGrid.add(manageSpecialGroupsButton, 0, 11);   // Manage Special Groups



    // Set actions for articles
    createArticleButton.setOnAction(e -> showArticleDialog(null));
    updateArticleButton.setOnAction(e -> showUpdateArticleDialog());
    deleteArticleButton.setOnAction(e -> showDeleteArticleDialog());
    listArticlesButton.setOnAction(e -> showArticleList());
    listArticles();
    listArticlesGroupButton.setOnAction(e -> handleListArticlesByGroup());
    backupButton.setOnAction(e -> handleBackup());
    restoreButton.setOnAction(e -> handleRestore());
    showArticlesButton.setOnAction(e -> handleViewArticle());
    //listArticlesButton.setOnAction(e -> listArticles());
    
    // Set actions for user management buttons
    inviteButton.setOnAction(e -> triggerUserInvite());
    passwordResetButton.setOnAction(e -> triggerResetPassword());
    deleteAccountButton.setOnAction(e -> triggerDelete());
    listUsersButton.setOnAction(e -> triggerUserList());
    logoutButton.setOnAction(e -> triggerLogout());
    
    // Set button actions for help messages
    viewHelpMessagesButton.setOnAction(e -> viewHelpMessages());
    deleteHelpMessageButton.setOnAction(e -> deleteHelpMessage());
    
    // Assign Actions to New Buttons
    addUserToGroupButton.setOnAction(e -> handleAddUserToGroup());
    viewGroupUsersButton.setOnAction(e -> handleViewGroupUsers());
    removeUserFromGroupButton.setOnAction(e -> handleRemoveUserFromGroup());
    manageGeneralGroupsButton.setOnAction(e -> handleManageGeneralGroups());
    manageSpecialGroupsButton.setOnAction(e -> handleManageSpecialGroups());

    return new Scene(homeGrid, 500, 600);  // Adjusted size to fit all buttons
  }

  /**
   * Displays a dialog for performing a backup of articles.
   * Allows the admin to specify a group for the backup or leave it blank for all articles.
   */
  private void handleBackup() {
	    TextInputDialog groupInputDialog = new TextInputDialog();
	    groupInputDialog.setTitle("Backup Group");
	    groupInputDialog.setHeaderText("Enter Group Name (leave empty to backup all articles)");
	    groupInputDialog.setContentText("Group:");

	    Optional<String> groupResult = groupInputDialog.showAndWait();
	    groupResult.ifPresent(group -> {
	        FileChooser fileChooser = new FileChooser();
	        fileChooser.setTitle("Save Backup File");
	        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Backup Files", "*.dat"));
	        File file = fileChooser.showSaveDialog(mainStage);

	        if (file != null) {
	            helpSystem.backupArticlesByGroup(file.getAbsolutePath(), group.trim());
	        }
	    });
	}

  /**
   * Displays a dialog for restoring articles from a backup file.
   * Provides options to either clear existing articles or merge with current articles.
   */
  private void handleRestore() {
      FileChooser fileChooser = new FileChooser();
      fileChooser.setTitle("Select Backup File");
      fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Backup Files", "*.dat"));
      File file = fileChooser.showOpenDialog(mainStage);

      if (file != null) {
          ChoiceDialog<String> dialog = new ChoiceDialog<>("Clear existing articles", "Clear existing articles", "Merge with current articles");
          dialog.setTitle("Restore Options");
          dialog.setHeaderText("Choose Restore Option");
          dialog.setContentText("Select action:");

          Optional<String> result = dialog.showAndWait();
          result.ifPresent(choice -> {
              boolean clearCurrent = choice.equals("Clear existing articles");
              helpSystem.restoreArticles(file.getAbsolutePath(), clearCurrent);
          });
      }
  }

  /**
   * Opens a dialog for creating or updating an article.
   * If an article is provided, the dialog is populated for editing.
   * 
   * @param article The article to edit, or null if creating a new article
   */
  private void showArticleDialog(Article article) {
    ArticleDialog dialog = new ArticleDialog(mainStage, helpSystem, article);
    dialog.showAndWait();
  }

  /**
   * Prompts the admin to enter an article ID to update.
   * Searches for the article and opens the article dialog for editing if found.
   */
  private void showUpdateArticleDialog() {
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Update Article");
	    dialog.setHeaderText("Enter the ID of the article you want to update:");
	    dialog.setContentText("Article ID:");

	    Optional<String> result = dialog.showAndWait();

	    result.ifPresent(idStr -> {
	        try {
	            long articleId = Long.parseLong(idStr); // Parse the article ID from the dialog input
	            System.out.println("Searching for article with ID: " + articleId); // Debug

	            Article selectedArticle = helpSystem.findArticleById(articleId);

	            if (selectedArticle != null) {
	                System.out.println("Article found. Opening update dialog."); // Debug
	                showArticleDialog(selectedArticle); // Pass selected article for updating
	            } else {
	                System.out.println("Article not found for updating.");
	                showAlert("Error", "Article with ID " + articleId + " not found.");
	            }
	        } catch (NumberFormatException e) {
	            System.out.println("Invalid input. Please enter a valid numeric article ID.");
	            showAlert("Input Error", "Please enter a valid numeric article ID.");
	        }
	    });
	}

  /**
   * Prompts the admin to enter an article ID to view.
   * Displays the article details if found.
   */
  private void handleViewArticle() {
	    // Prompt user for Article ID
	    TextInputDialog idInputDialog = new TextInputDialog();
	    idInputDialog.setTitle("View Article");
	    idInputDialog.setHeaderText("Enter the ID of the article you want to view");
	    idInputDialog.setContentText("Article ID:");

	    Optional<String> result = idInputDialog.showAndWait();
	    result.ifPresent(idString -> {
	        try {
	            long articleId = Long.parseLong(idString.trim());
	            Article article = helpSystem.findArticleById(articleId);

	            if (article != null) {
	                displayArticle(article);
	            } else {
	                showAlert("Error", "No article found with ID: " + articleId);
	            }
	        } catch (NumberFormatException ex) {
	            showAlert("Error", "Invalid ID format. Please enter a numeric ID.");
	        }
	    });
	}

  /**
   * Displays the details of an article in a separate stage.
   * Sets up a form view of the article fields (title, level, description, etc.).
   * 
   * @param article The article to display
   */
	private void displayArticle(Article article) {
	    Stage articleStage = new Stage();
	    articleStage.setTitle("Article Details");

	    // Layout for displaying article details
	    GridPane articleLayout = new GridPane();
	    articleLayout.setPadding(new Insets(10));
	    articleLayout.setVgap(10);
	    articleLayout.setHgap(10);
	    articleLayout.setAlignment(Pos.CENTER_LEFT);

	    articleLayout.add(new Label("Title:"), 0, 0);
	    articleLayout.add(new TextField(article.getTitle()), 1, 0);
	    
	    articleLayout.add(new Label("Level:"), 0, 1);
	    articleLayout.add(new TextField(article.getLevel()), 1, 1);
	    
	    articleLayout.add(new Label("Short Description:"), 0, 2);
	    articleLayout.add(new TextField(article.getShortDescription()), 1, 2);
	    
	    articleLayout.add(new Label("Keywords:"), 0, 3);
	    articleLayout.add(new TextField(article.getKeywords()), 1, 3);
	    
	    articleLayout.add(new Label("Body:"), 0, 4);
	    TextArea bodyText = new TextArea(article.getBody());
	    bodyText.setWrapText(true);
	    bodyText.setPrefHeight(100);
	    articleLayout.add(bodyText, 1, 4);
	    
	    articleLayout.add(new Label("References:"), 0, 5);
	    articleLayout.add(new TextField(article.getReferences()), 1, 5);
	    
	    articleLayout.add(new Label("Groups:"), 0, 6);
	    articleLayout.add(new TextField(String.join(", ", article.getGroups())), 1, 6);

	    // Back button to close the window
	    Button backButton = new Button("Back");
	    backButton.setOnAction(e -> articleStage.close());
	    articleLayout.add(backButton, 1, 7);

	    Scene scene = new Scene(articleLayout, 600, 500);
	    articleStage.setScene(scene);
	    articleStage.show();
	}

  
	/**
     * Displays an alert dialog with the provided title and message.
     * Used for error notifications and informational messages.
     * 
     * @param title The title of the alert dialog
     * @param message The message content of the alert dialog
     */
	private void showAlert(String title, String message) {
	    Alert alert = new Alert(Alert.AlertType.ERROR);
	    alert.setTitle(title);
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.showAndWait();
	}

	/**
     * Prompts the admin to enter an article ID to delete.
     * Attempts to delete the article from the HelpSystem if it exists.
     */
  private void showDeleteArticleDialog() {
	    // Create a dialog for entering the article ID to delete
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Delete Article by ID");
	    dialog.setHeaderText("Delete Article by ID");
	    dialog.setContentText("Please enter the ID of the article you want to delete:");

	    // Show the dialog and capture the result
	    Optional<String> result = dialog.showAndWait();

	    // If the user provided an ID, attempt to delete the article
	    result.ifPresent(idStr -> {
	        try {
	            long id = Long.parseLong(idStr); // Parse the ID input as a long
	            boolean deleted = helpSystem.deleteArticle(id); // Try to delete the article

	            // Notify the user about the deletion result
	            if (deleted) {
	                System.out.println("Article with ID " + id + " was successfully deleted.");
	            } else {
	                System.out.println("Article with ID " + id + " not found.");
	            }
	        } catch (NumberFormatException e) {
	            System.out.println("Invalid ID format. Please enter a numeric ID.");
	        }
	    });
	}

  /**
   * Retrieves and displays a list of all articles in the system.
   * Uses an ArticleListDialog to present the articles in a tabular view.
   */
  private void showArticleList() {
	    // Retrieve articles from HelpSystem
	    ObservableList<Article> articles = FXCollections.observableArrayList(helpSystem.getAllArticles());
	    
	    // Create and display the ArticleListDialog with the list of articles
	    ArticleListDialog articleListDialog = new ArticleListDialog(mainStage, articles);
	    articleListDialog.showAndWait();
	}

  /**
   * Retrieves and prints a list of all articles in the system to the console.
   * Outputs detailed information about each article.
   */
  private void listArticles() {
	    List<Article> articles = helpSystem.getAllArticles(); // Assuming getAllArticles() returns a list of articles

	    if (articles.isEmpty()) {
	        System.out.println("No articles found.");
	    } else {
	        System.out.println("Articles List:");
	        for (Article article : articles) {
	            System.out.println("ID: " + article.getId());
	            System.out.println("Title: " + article.getTitle());
	            System.out.println("Level: " + article.getLevel());
	            System.out.println("Short Description: " + article.getShortDescription());
	            System.out.println("Keywords: " + article.getKeywords());
	            System.out.println("Body: " + article.getBody());
	            System.out.println("References: " + article.getReferences());
	            System.out.println("Groups: " + article.getGroups());
	            System.out.println("--------------------------------------------------");
	        }
	    }
	}
 
  /**
   * Prompts the admin to enter a group name and displays a list of articles belonging to that group.
   * If no articles are found, an alert is shown.
   */
  private void handleListArticlesByGroup() {
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Enter Group Name");
	    dialog.setHeaderText("List Articles by Group");
	    dialog.setContentText("Please enter the group name:");

	    Optional<String> result = dialog.showAndWait();
	    result.ifPresent(groupName -> {
	        List<Article> articlesInGroup = helpSystem.getArticlesByGroup(groupName);
	        if (articlesInGroup.isEmpty()) {
	            showAlert("No Articles Found", "No articles found for group: " + groupName);
	        } else {
	            displayArticlesInGroup(articlesInGroup);
	        }
	    });
	}

  /**
   * Displays a list of articles in a new window based on the provided group.
   * Shows a table with columns for article ID and title.
   * 
   * @param articles The list of articles to display
   */
  private void displayArticlesInGroup(List<Article> articles) {
	    Stage groupStage = new Stage();
	    groupStage.setTitle("Articles in Group");

	    TableView<Article> articleTable = new TableView<>();
	    articleTable.setItems(FXCollections.observableArrayList(articles));

	    TableColumn<Article, Long> idColumn = new TableColumn<>("ID");
	    idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

	    TableColumn<Article, String> titleColumn = new TableColumn<>("Title");
	    titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

	    articleTable.getColumns().addAll(idColumn, titleColumn);

	    VBox vbox = new VBox(articleTable);
	    Scene scene = new Scene(vbox);
	    groupStage.setScene(scene);
	    groupStage.show();
	}

// Method to handle user account deletion functionality
private void triggerDelete() {
  RemoveAccountPage removeAccountPage = new RemoveAccountPage(mainStage, userAdminController);
  mainStage.setScene(removeAccountPage.deleteUserCreate()); // Switch to the account removal page
}

// Method to handle displaying the list of users
private void triggerUserList() {
  UsersListPage usersListPage = new UsersListPage(mainStage, userAdminController);
  mainStage.setScene(usersListPage.triggerUserList()); // Switch to the user list page
}

// Method to handle password reset functionality
private void triggerResetPassword() {
  PasswordResetPage passwordResetPage = new PasswordResetPage(mainStage, userAdminController);
  mainStage.setScene(passwordResetPage.Resetting()); // Switch to the password reset page
}

// Method to handle user invitation functionality
private void triggerUserInvite() {
  InvitePage invitePage = new InvitePage(userAdminController, mainStage);
  mainStage.setScene(invitePage.adminPageCreate()); // Switch to the invite page
}

//method handle logout
private void triggerLogout() {
    // Ensure loginController is properly initialized with the login scene
    LoginController loginController = new LoginController(mainStage, userAdminController, helpSystem);
    
    // Set the new scene to the login page
    Scene loginScene = loginController.triggerLoginPage();
    mainStage.setScene(loginScene);
    
    // Display the stage with the updated scene
    mainStage.show();
}

//phase 4 new implementation
private void viewHelpMessages() {
    List<String> messages = helpSystem.getAllMessages(); // Retrieve messages

    if (messages.isEmpty()) {
        showMessage("No messages available.");
        return;
    }

    StringBuilder messageDisplay = new StringBuilder("Help System Messages:\n\n");
    for (int i = 0; i < messages.size(); i++) {
        messageDisplay.append((i + 1)).append(". ").append(messages.get(i)).append("\n\n");
    }

    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle("Help Messages");
    alert.setHeaderText("Messages from Students:");
    TextArea textArea = new TextArea(messageDisplay.toString());
    textArea.setWrapText(true);
    textArea.setEditable(false);
    textArea.setPrefSize(500, 400);
    alert.getDialogPane().setContent(textArea);
    alert.showAndWait();
}

private void deleteHelpMessage() {
    List<String> messages = helpSystem.getAllMessages(); // Retrieve messages

    if (messages.isEmpty()) {
        showMessage("No messages available to delete.");
        return;
    }

    StringBuilder messageDisplay = new StringBuilder("Help System Messages:\n\n");
    for (int i = 0; i < messages.size(); i++) {
        messageDisplay.append((i + 1)).append(". ").append(messages.get(i)).append("\n\n");
    }

    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("Delete Help Message");
    dialog.setHeaderText("Help Messages:");
    dialog.setContentText("Enter the sequence number of the message to delete:\n\n" + messageDisplay);

    Optional<String> result = dialog.showAndWait();
    result.ifPresent(input -> {
        try {
            int sequenceNumber = Integer.parseInt(input.trim());
            boolean deleted = helpSystem.deleteMessage(sequenceNumber);

            if (deleted) {
                showMessage("Message " + sequenceNumber + " deleted successfully.");
            } else {
                showMessage("Invalid sequence number. Please try again.");
            }
        } catch (NumberFormatException e) {
            showMessage("Invalid input. Please enter a numeric sequence number.");
        }
    });
}

private void showMessage(String message) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle("Information");
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}

private void handleAddUserToGroup() {
    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("Add User to Group");
    dialog.setHeaderText("Enter the username and group name:");
    dialog.setContentText("Format: username,group");

    Optional<String> result = dialog.showAndWait();
    result.ifPresent(input -> {
        String[] parts = input.split(",");
        if (parts.length == 2) {
            String username = parts[0].trim();
            String groupName = parts[1].trim();
            boolean success = helpSystem.addStudentToGroup(username, groupName);
            showMessage(success ? "User added to group successfully." : "Failed to add user to group.");
        } else {
            showMessage("Invalid input format. Use: username,group");
        }
    });
}

private void handleViewGroupUsers() {
    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("View Users in Group");
    dialog.setHeaderText("Enter the group name:");
    dialog.setContentText("Group:");

    Optional<String> result = dialog.showAndWait();
    result.ifPresent(groupName -> {
        List<String> users = helpSystem.getStudentsInGroup(groupName.trim());
        if (users.isEmpty()) {
            showMessage("No users found in the group: " + groupName);
        } else {
            StringBuilder userList = new StringBuilder("Users in group " + groupName + ":\n");
            for (String user : users) {
                userList.append("- ").append(user).append("\n");
            }
            showMessage(userList.toString());
        }
    });
}

private void handleRemoveUserFromGroup() {
    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("Remove User from Group");
    dialog.setHeaderText("Enter the username and group name:");
    dialog.setContentText("Format: username,group");

    Optional<String> result = dialog.showAndWait();
    result.ifPresent(input -> {
        String[] parts = input.split(",");
        if (parts.length == 2) {
            String username = parts[0].trim();
            String groupName = parts[1].trim();
            boolean success = helpSystem.removeStudentFromGroup(username, groupName);
            showMessage(success ? "User removed from group successfully." : "Failed to remove user from group.");
        } else {
            showMessage("Invalid input format. Use: username,group");
        }
    });
}

private void handleManageGeneralGroups() {
    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("Manage General Groups");
    dialog.setHeaderText("Enter the group name to add or delete:");
    dialog.setContentText("Group Name:");

    Optional<String> result = dialog.showAndWait();
    result.ifPresent(groupName -> {
        ChoiceDialog<String> choiceDialog = new ChoiceDialog<>("Add Group", "Add Group", "Delete Group");
        choiceDialog.setTitle("Choose Action");
        choiceDialog.setHeaderText("Manage Group: " + groupName);
        choiceDialog.setContentText("Choose action:");

        Optional<String> action = choiceDialog.showAndWait();
        action.ifPresent(choice -> {
            if (choice.equals("Add Group")) {
                boolean added = helpSystem.addGeneralGroup(groupName);
                showMessage(added ? "Group added successfully." : "Group already exists.");
            } else if (choice.equals("Delete Group")) {
                boolean deleted = helpSystem.deleteGeneralGroup(groupName);
                showMessage(deleted ? "Group deleted successfully." : "Group does not exist.");
            }
        });
    });
}

private void handleManageSpecialGroups() {
    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("Manage Special Groups");
    dialog.setHeaderText("Enter the group name to add or delete:");
    dialog.setContentText("Group Name:");

    Optional<String> result = dialog.showAndWait();
    result.ifPresent(groupName -> {
        ChoiceDialog<String> choiceDialog = new ChoiceDialog<>("Add Group", "Add Group", "Delete Group");
        choiceDialog.setTitle("Choose Action");
        choiceDialog.setHeaderText("Manage Group: " + groupName);
        choiceDialog.setContentText("Choose action:");

        Optional<String> action = choiceDialog.showAndWait();
        action.ifPresent(choice -> {
            if (choice.equals("Add Group")) {
                boolean added = helpSystem.addSpecialGroup(groupName);
                showMessage(added ? "Special group added successfully." : "Special group already exists.");
            } else if (choice.equals("Delete Group")) {
                boolean deleted = helpSystem.deleteSpecialGroup(groupName);
                showMessage(deleted ? "Special group deleted successfully." : "Special group does not exist.");
            }
        });
    });
}

}

