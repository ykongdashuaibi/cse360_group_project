module CSE360_P_1 {
	requires javafx.controls;
	requires java.sql;
	requires static org.junit.jupiter.api; // Mark JUnit as a compile-time only dependency
	// Export the primary packages for access by JavaFX and other application components
    exports application;
    exports application_phase2;
	opens application to javafx.graphics, javafx.fxml;
}
