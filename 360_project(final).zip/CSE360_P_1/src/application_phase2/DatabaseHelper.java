package application_phase2;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import application.User;
import application.Role;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The DatabaseHelper class provides methods for interacting with a database to
 * store and retrieve help system articles. It uses JDBC to connect to an H2
 * database and supports operations like saving, loading, deleting articles, and
 * creating tables.
 */
class DatabaseHelper {
    // JDBC Driver and connection parameters
    static final String JDBC_DRIVER = "org.h2.Driver";
    static final String DB_URL = "jdbc:h2:~/helpSystemDatabase";
    static final String USER = "sa";      // Database user
    static final String PASS = "";        // Database password (empty for H2)

    // Connection and Statement objects for interacting with the database
    private Connection connection;
    private Statement statement;

    /**
     * Constructor for the DatabaseHelper class.
     * Initializes the database connection.
     */
    public DatabaseHelper() throws SQLException {
        connectToDatabase();
    }

    /**
     * Connects to the H2 database and creates the necessary table for storing articles.
     * 
     * @throws SQLException if a database connection or SQL execution error occurs.
     */
    public void connectToDatabase() throws SQLException {
        try {
            Class.forName(JDBC_DRIVER);  // Load the JDBC driver
            connection = DriverManager.getConnection(DB_URL, USER, PASS);  // Establish connection
            statement = connection.createStatement();  // Create statement
            createTables();  // Ensure the tables exist
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
        }
    }

    /**
     * Creates the helpArticles table in the database if it does not already exist.
     * The table stores each article's details.
     * 
     * @throws SQLException if there is an error creating the table.
     */
    private void createTables() throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS helpArticles ("
                + "id BIGINT PRIMARY KEY, "
                + "title TEXT, "
                + "level TEXT, "
                + "shortDescription TEXT, "
                + "keywords TEXT, "
                + "body TEXT, "
                + "references TEXT, "
                + "groups TEXT)";
        statement.execute(createTableSQL);
    }

    /**
     * Saves an article to the database.
     * 
     * @param article The Article object to be saved.
     * @throws SQLException if there is an error executing the SQL insert operation.
     */
    public void saveArticle(Article article) throws SQLException {
        String sql = "INSERT INTO helpArticles (id, title, level, shortDescription, keywords, body, references, groups) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setLong(1, article.getId());
            pstmt.setString(2, article.getTitle());
            pstmt.setString(3, article.getLevel());
            pstmt.setString(4, article.getShortDescription());
            pstmt.setString(5, article.getKeywords());
            pstmt.setString(6, article.getBody());
            pstmt.setString(7, article.getReferences());
            pstmt.setString(8, String.join(",", article.getGroups()));
            pstmt.executeUpdate();
        }
    }

    /**
     * Loads all articles from the database and returns them as a list of Article objects.
     * 
     * @return A list of Article objects.
     * @throws SQLException if there is an error executing the SQL query.
     */
    public List<Article> loadAllArticles() throws SQLException {
        List<Article> articles = new ArrayList<>();
        String sql = "SELECT * FROM helpArticles";
        try (ResultSet rs = statement.executeQuery(sql)) {
            while (rs.next()) {
                long id = rs.getLong("id");
                String title = rs.getString("title");
                String level = rs.getString("level");
                String shortDescription = rs.getString("shortDescription");
                String keywords = rs.getString("keywords");
                String body = rs.getString("body");
                String references = rs.getString("references");
                String groupsStr = rs.getString("groups");
                List<String> groups = List.of(groupsStr.split(","));
                
                Article article = new Article(id, title, level, shortDescription, keywords, body, references, false);
                groups.forEach(article::addGroup);
                articles.add(article);
            }
        } catch (SQLException e) {
            System.out.println("Error loading articles: " + e.getMessage());
        }
        return articles;
    }

    /**
     * Updates an existing article in the database.
     */
    public void updateArticle(Article article) throws SQLException {
        String sql = "UPDATE helpArticles SET title = ?, level = ?, shortDescription = ?, keywords = ?, body = ?, references = ?, groups = ? WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, article.getTitle());
            pstmt.setString(2, article.getLevel());
            pstmt.setString(3, article.getShortDescription());
            pstmt.setString(4, article.getKeywords());
            pstmt.setString(5, article.getBody());
            pstmt.setString(6, article.getReferences());
            pstmt.setString(7, String.join(",", article.getGroups()));
            pstmt.setLong(8, article.getId());
            pstmt.executeUpdate();
        }
    }

    /**
     * Deletes an article by ID.
     */
    public void deleteArticle(long id) throws SQLException {
        String sql = "DELETE FROM helpArticles WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setLong(1, id);
            pstmt.executeUpdate();
        }
    }

    /**
     * Clears all articles from the database.
     */
    public void clearArticles() throws SQLException {
        String sql = "DELETE FROM helpArticles";
        statement.executeUpdate(sql);
    }

    /**
     * Closes the database connection and statement.
     */
    public void closeConnection() throws SQLException {
        if (statement != null) statement.close();
        if (connection != null) connection.close();
    }
    
    //new added method for phase 4
    // Save user data to the database
    public void saveUserData(User user) throws SQLException {
        String query = "INSERT INTO users (username, password, email, first_name, middle_name, last_name, preferred_name, roles, setup) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                       "ON CONFLICT(username) DO UPDATE SET password = excluded.password, " +
                       "email = excluded.email, first_name = excluded.first_name, " +
                       "middle_name = excluded.middle_name, last_name = excluded.last_name, " +
                       "preferred_name = excluded.preferred_name, roles = excluded.roles, setup = excluded.setup";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getFirstName());
            stmt.setString(5, user.getMiddleName());
            stmt.setString(6, user.getLastName());
            stmt.setString(7, user.getPreferredName());
            stmt.setString(8, String.join(",", user.getRoles().stream().map(Role::name).toList())); // Assuming Role is an enum
            stmt.setBoolean(9, user.detectCompleteSetup());
            stmt.executeUpdate();
        }
    }

    // Load all users from the database
    public List<User> loadAllUsers() throws SQLException {
        List<User> users = new ArrayList<>();
        String query = "SELECT username, password, email, first_name, middle_name, last_name, preferred_name, roles, setup FROM users";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                String email = rs.getString("email");
                String firstName = rs.getString("first_name");
                String middleName = rs.getString("middle_name");
                String lastName = rs.getString("last_name");
                String preferredName = rs.getString("preferred_name");
                Set<Role> roles = Arrays.stream(rs.getString("roles").split(","))
                                        .map(Role::valueOf)
                                        .collect(Collectors.toSet());
                boolean setup = rs.getBoolean("setup");

                User user = new User(username, password, roles);
                user.setEmail(email);
                user.setFirstName(firstName);
                user.setMiddleName(middleName);
                user.setLastName(lastName);
                user.setPreferredName(preferredName);
                user.completedSetup(setup);
                users.add(user);
            }
        }
        return users;
    }
}
