package application_phase2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.input.KeyEvent;

/**
 * The ArticleListDialog class provides a dialog window that displays a list of articles in a table format.
 * It allows users to view details of multiple articles in a structured table with columns such as ID,
 * title, level, short description, keywords, body, and references. It also includes a search functionality.
 *
 * <p>This dialog is modal and blocks interaction with the owner stage until it is closed.</p>
 */
public class ArticleListDialog {

    private Stage dialogStage;
    private TableView<Article> articleTable;
    private ObservableList<Article> allArticles;

    /**
     * Constructor for initializing the ArticleListDialog.
     * 
     * @param ownerStage The stage that owns this dialog, which will be blocked when the dialog is shown
     * @param articles   An observable list of articles to display in the table
     */
    public ArticleListDialog(Stage ownerStage, ObservableList<Article> articles) {
        dialogStage = new Stage();
        dialogStage.initOwner(ownerStage);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Articles List");

        allArticles = articles;

        // Table setup
        articleTable = new TableView<>(allArticles);
        setupTableColumns();

        // Search bar setup
        TextField searchField = new TextField();
        searchField.setPromptText("Search articles...");
        searchField.setOnKeyReleased(event -> searchArticles(searchField.getText()));

        // Cancel button setup
        Button cancelButton = new Button("Cancel");
        cancelButton.setOnAction(e -> dialogStage.close());

        // Layout setup
        VBox layout = new VBox(10, searchField, articleTable, cancelButton); // Spacing of 10
        Scene scene = new Scene(layout);
        dialogStage.setScene(scene);
    }

    /**
     * Configures the columns for the article table, setting up each column to display specific properties of the Article object.
     */
    private void setupTableColumns() {
        TableColumn<Article, Long> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Article, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

        TableColumn<Article, String> levelColumn = new TableColumn<>("Level");
        levelColumn.setCellValueFactory(new PropertyValueFactory<>("level"));

        TableColumn<Article, String> shortDescriptionColumn = new TableColumn<>("Short Description");
        shortDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("shortDescription"));

        TableColumn<Article, String> keywordsColumn = new TableColumn<>("Keywords");
        keywordsColumn.setCellValueFactory(new PropertyValueFactory<>("keywords"));

        TableColumn<Article, String> bodyColumn = new TableColumn<>("Body");
        bodyColumn.setCellValueFactory(new PropertyValueFactory<>("body"));

        TableColumn<Article, String> referencesColumn = new TableColumn<>("References");
        referencesColumn.setCellValueFactory(new PropertyValueFactory<>("references"));

        articleTable.getColumns().addAll(idColumn, titleColumn, levelColumn, shortDescriptionColumn, keywordsColumn, bodyColumn, referencesColumn);
    }

    /**
     * Filters the articles based on the search query.
     * 
     * @param query The search query entered by the user
     */
    private void searchArticles(String query) {
        if (query.isEmpty()) {
            // If the query is empty, show all articles
            articleTable.setItems(allArticles);
        } else {
            // Filter articles based on the query (title, keywords, and short description)
            ObservableList<Article> filteredArticles = FXCollections.observableArrayList();

            for (Article article : allArticles) {
                if (article.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                    article.getKeywords().toLowerCase().contains(query.toLowerCase()) ||
                    article.getShortDescription().toLowerCase().contains(query.toLowerCase())) {
                    filteredArticles.add(article);
                }
            }

            articleTable.setItems(filteredArticles); // Set filtered list
        }
    }

    /**
     * Displays the dialog and waits until it is closed.
     */
    public void showAndWait() {
        dialogStage.showAndWait();
    }
}
