package application_phase2;

import org.junit.jupiter.api.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class RestoreArticlesTest {

    private HelpSystem helpSystem;
    private static final String RESTORE_FILE = "testRestore.ser";

    @BeforeEach
    void setUp() throws Exception {
        // Initialize the HelpSystem
        helpSystem = new HelpSystem();
    }

    @AfterEach
    void tearDown() {
        // Clean up the restore file
        new File(RESTORE_FILE).delete();
    }

    @Test
    void testRestoreArticles() throws Exception {
        // Prepare a backup file with test articles
        List<Article> backupArticles = List.of(
            new Article(1L, "Article 1", "Beginner", "Short Desc 1", "keyword1", "Body 1", "Reference 1", false),
            new Article(2L, "Article 2", "Intermediate", "Short Desc 2", "keyword2", "Body 2", "Reference 2", false)
        );

        // Write the articles to a file (restore file)
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(RESTORE_FILE))) {
            oos.writeObject(backupArticles);
        }

        // Perform the restore
        helpSystem.restoreArticles(RESTORE_FILE, true);

        // Verify the restored articles
        List<Article> restoredArticles = helpSystem.getAllArticles();
        assertEquals(2, restoredArticles.size(), "The restored list should contain 2 articles");
        assertEquals("Article 1", restoredArticles.get(0).getTitle(), "First article title should match");
        assertEquals("Article 2", restoredArticles.get(1).getTitle(), "Second article title should match");
    }
}
