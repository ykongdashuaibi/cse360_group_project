package application_phase2;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//this is just console log program used to text phase 2
public class HelpSystemCLI {
    private static HelpSystem helpSystem;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            helpSystem = new HelpSystem(); // Instantiate HelpSystem with exception handling
            boolean running = true;

            System.out.println("Welcome to the Help System");

            while (running) {
                showMenu();
                String choice = scanner.nextLine();

                switch (choice) {
                    case "1":
                        createArticle();
                        break;
                    case "2":
                        updateArticle();
                        break;
//                    case "3":
//                        deleteArticle();
//                        break;
                    case "4":
                        listArticlesByGroup();
                        break;
                    case "5":
                        backupArticlesByGroup();
                        break;
                    case "6":
                        restoreArticles();
                        break;
                    case "7":
                        searchArticles();
                        break;
                    case "8":
                        running = false;
                        System.out.println("Exiting Help System.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please select a valid option.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error initializing the help system: " + e.getMessage());
        }
    }


    // Display the main menu
    public static void showMenu() {
        System.out.println("\nMain Menu:");
        System.out.println("1. Create Article");
        System.out.println("2. Update Article");
        System.out.println("3. Delete Article");
        System.out.println("4. List Articles by Group");
        System.out.println("5. Backup Articles by Group");
        System.out.println("6. Restore Articles");
        System.out.println("7. Search Articles by Keyword");
        System.out.println("8. Exit");
        System.out.print("Enter your choice: ");
    }

    // Method to create a new article
    public static void createArticle() {
        System.out.print("Enter Article ID (unique long integer): ");
        long id = Long.parseLong(scanner.nextLine());
        System.out.print("Enter Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Level (Beginner, Intermediate, Advanced, Expert): ");
        String level = scanner.nextLine();
        System.out.print("Enter Short Description: ");
        String shortDescription = scanner.nextLine();
        System.out.print("Enter Keywords (comma-separated): ");
        String keywords = scanner.nextLine();
        System.out.print("Enter Body of the Article: ");
        String body = scanner.nextLine();
        System.out.print("Enter References (comma-separated links): ");
        String references = scanner.nextLine();

        // Group input
        System.out.print("Enter Groups (comma-separated, e.g., Eclipse, H2): ");
        String groupInput = scanner.nextLine();
        List<String> groups = List.of(groupInput.split(","));

        try {
            helpSystem.createArticle(id, title, level, shortDescription, keywords, body, references, groups);
            System.out.println("Article created successfully.");
        } catch (Exception e) {
            System.out.println("Error creating article: " + e.getMessage());
        }
    }

    // Method to update an existing article
    public static void updateArticle() {
        System.out.print("Enter Article ID to update: ");
        long id = Long.parseLong(scanner.nextLine());

        System.out.print("Enter New Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter New Level (Beginner, Intermediate, Advanced, Expert): ");
        String level = scanner.nextLine();
        System.out.print("Enter New Short Description: ");
        String shortDescription = scanner.nextLine();
        System.out.print("Enter New Keywords (comma-separated): ");
        String keywords = scanner.nextLine();
        System.out.print("Enter New Body of the Article: ");
        String body = scanner.nextLine();
        System.out.print("Enter New References (comma-separated links): ");
        String references = scanner.nextLine();

        // Group input
        System.out.print("Enter New Groups (comma-separated): ");
        String groupInput = scanner.nextLine();
        List<String> groups = List.of(groupInput.split(","));

        try {
            helpSystem.updateArticle(id, title, level, shortDescription, keywords, body, references, groups);
            System.out.println("Article updated successfully.");
        } catch (Exception e) {
            System.out.println("Error updatting article: " + e.getMessage());
        }
    }

    // Method to delete an article
//    public static void deleteArticle() {
//        try {
//            System.out.print("Enter Article ID to delete: ");
//            long id = Long.parseLong(scanner.nextLine());
//            helpSystem.deleteArticle(id);
//            System.out.println("Article deleted successfully.");
//        } catch (SQLException e) {
//            System.err.println("Error deleting article: " + e.getMessage());
//        }
//    }
    
    // Method to list articles by group
    public static void listArticlesByGroup() {
        System.out.print("Enter Group Name to list articles: ");
        String group = scanner.nextLine();
        helpSystem.listArticlesByGroup(group);
    }

    // Method to back up articles by group
    public static void backupArticlesByGroup() {
        System.out.print("Enter Group Name to back up: ");
        String group = scanner.nextLine();
        System.out.print("Enter Filename for backup: ");
        String filename = scanner.nextLine();
        //helpSystem.backupArticlesByGroup(filename, group);
    }

    // Method to restore articles
    public static void restoreArticles() {
        System.out.print("Enter Filename to restore from: ");
        String filename = scanner.nextLine();
        System.out.print("Overwrite current articles? (yes/no): ");
        boolean overwrite = scanner.nextLine().equalsIgnoreCase("yes");
        helpSystem.restoreArticles(filename, overwrite);
    }

    // Method to search articles by keyword
    public static void searchArticles() {
        System.out.print("Enter Keyword to search articles: ");
        String keyword = scanner.nextLine();
        helpSystem.searchArticles(keyword);
    }
}
