package application_phase2;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import application_phase2.HelpSystem;
import application_phase2.Article;
import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;

/**
 * The ArticleDialog class provides a dialog window for creating or editing an article.
 * It allows the user to input or modify article details including title, level, description,
 * keywords, body, references, and groups. The dialog supports saving the article information
 * to the HelpSystem or closing without changes.
 *
 * <p>This dialog is modal and blocks interaction with the owner stage until closed.</p>
 *
 * @see HelpSystem
 * @see Article
 */
public class ArticleDialog {
    private Stage dialogStage;
    private HelpSystem helpSystem;
    private Article article;

    private TextField titleField;
    private TextField levelField;
    private TextField shortDescriptionField;
    private TextField keywordsField;
    private TextArea bodyField;
    private TextField referencesField;
    private TextField groupsField;
    private Button saveButton; // Declare saveButton here
    private Button cancelButton; // Declare cancelButton here

    /**
     * Constructor for initializing an ArticleDialog.
     * 
     * @param ownerStage    The owner stage that blocks interaction when this dialog is open
     * @param helpSystem    The HelpSystem instance used to save the article
     * @param article       The article to edit, or null if creating a new article
     */
    public ArticleDialog(Stage ownerStage, HelpSystem helpSystem, Article article) {
        this.dialogStage = new Stage();
        this.dialogStage.initOwner(ownerStage);
        this.dialogStage.initModality(Modality.APPLICATION_MODAL);

        this.helpSystem = helpSystem;
        this.article = article;

        initializeDialog();
    }

    /**
     * Initializes the dialog layout, setting up all UI components such as text fields
     * and buttons, and configures the dialog window title based on the action (create or edit).
     */
    private void initializeDialog() {
        dialogStage.setTitle(article == null ? "Create Article" : "Edit Article");

        // Initialize fields
        titleField = new TextField(article != null ? article.getTitle() : "");
        levelField = new TextField(article != null ? article.getLevel() : "");
        shortDescriptionField = new TextField(article != null ? article.getShortDescription() : "");
        keywordsField = new TextField(article != null ? article.getKeywords() : "");
        bodyField = new TextArea(article != null ? article.getBody() : "");
        referencesField = new TextField(article != null ? article.getReferences() : "");
        groupsField = new TextField(article != null ? String.join(", ", article.getGroups()) : "");

     // Initialize buttons
        saveButton = new Button("Save");
        saveButton.setOnAction(e -> handleSaveAction());

        cancelButton = new Button("Cancel");
        cancelButton.setOnAction(e -> dialogStage.close());

        // Arrange UI components in a grid
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        gridPane.add(new Label("Title:"), 0, 0);
        gridPane.add(titleField, 1, 0);
        gridPane.add(new Label("Level:"), 0, 1);
        gridPane.add(levelField, 1, 1);
        gridPane.add(new Label("Short Description:"), 0, 2);
        gridPane.add(shortDescriptionField, 1, 2);
        gridPane.add(new Label("Keywords:"), 0, 3);
        gridPane.add(keywordsField, 1, 3);
        gridPane.add(new Label("Body:"), 0, 4);
        gridPane.add(bodyField, 1, 4);
        gridPane.add(new Label("References:"), 0, 5);
        gridPane.add(referencesField, 1, 5);
        gridPane.add(new Label("Groups:"), 0, 6);
        gridPane.add(groupsField, 1, 6);
        gridPane.add(saveButton, 0, 7);
        gridPane.add(cancelButton, 1, 7);

        dialogStage.setScene(new Scene(gridPane));
    }

    /**
     * Handles the save action, gathering all input data from the dialog fields.
     * If the article is new, it creates a new entry in HelpSystem; otherwise, it updates the existing article.
     */
    private void handleSaveAction() {
        String title = titleField.getText();
        String level = levelField.getText();
        String shortDescription = shortDescriptionField.getText();
        String keywords = keywordsField.getText();
        String body = bodyField.getText();
        String references = referencesField.getText();
        List<String> groups = List.of(groupsField.getText().split(",\\s*")); // Split by commas and trim whitespace

        try {
            if (article == null) {
                // Creating a new article
                long uniqueId = System.currentTimeMillis(); // Example ID generation
                helpSystem.createArticle(uniqueId, title, level, shortDescription, keywords, body, references, groups);
                System.out.println("New article created.");
            } else {
                // Updating an existing article
                helpSystem.updateArticle(article.getId(), title, level, shortDescription, keywords, body, references, groups);
                System.out.println("Article updated.");
            }
        } catch (SQLException e) {
            System.out.println("Error saving the article: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            dialogStage.close(); // Close the dialog after attempting to save
        }
    }

    /**
     * Shows the dialog window and waits until it is closed.
     */
    public void showAndWait() {
        dialogStage.showAndWait();
    }
}
