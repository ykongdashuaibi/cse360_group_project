package application_phase2;

import application_phase2.Article;
import application_phase2.DatabaseHelper;
import application_phase2.HelpSystem;
import application.UserAccessControl;
import application.Role;
import application.User;
import application.AdminPage;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

/**
 * This class automates testing for non-GUI components in Phase 2.
 * It covers features like article creation, updating articles, 
 * and user role assignment in the `HelpSystem` and `UserAccessControl`.
 */
public class Phase2TestingAutomation {

    static int numPassed = 0;
    static int numFailed = 0;

    public static void main(String[] args) {
        System.out.println("Phase 2 Testing Automation");
        System.out.println("______________________________");

        testArticleCreation();
        testArticleGroupAssignment();
        testRoleAssignment();

        System.out.println("______________________________");
        System.out.println("Tests Passed: " + numPassed);
        System.out.println("Tests Failed: " + numFailed);
    }

    public static void testArticleCreation() {
        System.out.println("Test Case: Article Creation");

        try {
            HelpSystem helpSystem = new HelpSystem();
            long articleId = System.currentTimeMillis(); // Use unique ID for test
            String title = "Test Article";
            String level = "Beginner";
            String shortDescription = "This is a test article.";
            String keywords = "test, article";
            String body = "Test body content";
            String references = "Test reference";
            List<String> groups = List.of("Tech", "Science");

            // Create article
            helpSystem.createArticle(articleId, title, level, shortDescription, keywords, body, references, groups);

            // Verify the article exists in the system
            boolean articleExists = helpSystem.getAllArticles().stream()
                    .anyMatch(article -> article.getId() == articleId && article.getTitle().equals(title));

            if (articleExists) {
                System.out.println("Article creation successful.");
                numPassed++;
            } else {
                System.out.println("Article creation failed.");
                numFailed++;
            }
        } catch (Exception e) {
            System.out.println("Exception during article creation: " + e.getMessage());
            numFailed++;
        }
    }

    public static void testArticleGroupAssignment() {
        System.out.println("Test Case: Article Group Assignment");

        try {
            HelpSystem helpSystem = new HelpSystem();
            long articleId = System.currentTimeMillis();
            String title = "Group Test Article";
            String level = "Intermediate";
            String shortDescription = "Article for group testing";
            String keywords = "group, test";
            String body = "Content for group test article";
            String references = "Some references";
            List<String> groups = List.of("Tech");

            // Create article with group
            helpSystem.createArticle(articleId, title, level, shortDescription, keywords, body, references, groups);

            // Verify the article is in the correct group
            List<Article> techArticles = helpSystem.getArticlesByGroup("Tech");
            boolean articleInGroup = techArticles.stream()
                    .anyMatch(article -> article.getId() == articleId && article.getGroups().contains("Tech"));

            if (articleInGroup) {
                System.out.println("Group assignment successful.");
                numPassed++;
            } else {
                System.out.println("Group assignment failed.");
                numFailed++;
            }
        } catch (Exception e) {
            System.out.println("Exception during article group assignment: " + e.getMessage());
            numFailed++;
        }
    }

    public static void testRoleAssignment() {
        System.out.println("Test Case: Role Assignment");

        try {
            HelpSystem helpSystem = new HelpSystem();
            UserAccessControl userAccessControl = new UserAccessControl(helpSystem);
            Set<Role> roles = new HashSet<>();
            roles.add(Role.ADMIN);

            // Add a new user with the ADMIN role
            User adminUser = userAccessControl.implementUser("adminUser", "password123", roles);

            // Check if the role assignment is correct
            if (adminUser != null && adminUser.getRoles().contains(Role.ADMIN)) {
                System.out.println("Role assignment successful.");
                numPassed++;
            } else {
                System.out.println("Role assignment failed.");
                numFailed++;
            }
        } catch (Exception e) {
            System.out.println("Exception during role assignment test: " + e.getMessage());
            numFailed++;
        }
    }
}