package application_phase2;

import org.junit.jupiter.api.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

//Junit test for backup and restore
import org.junit.jupiter.api.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class BackupTest {

    private HelpSystem helpSystem;
    private static final String BACKUP_FILE = "testBackup.ser";
    private static final String RESTORE_FILE = "testRestore.ser";

    @BeforeEach
    void setUp() throws Exception {
        // Initialize the HelpSystem
        helpSystem = new HelpSystem();

        // Preload the HelpSystem with test articles
        helpSystem.createArticle(1L, "Test Article 1", "Beginner", "Short Desc 1", "keyword1", "Body 1", "Reference 1", List.of("Group1"));
        helpSystem.createArticle(2L, "Test Article 2", "Intermediate", "Short Desc 2", "keyword2", "Body 2", "Reference 2", List.of("Group2"));
    }

    @AfterEach
    void tearDown() {
        // Clean up test files after each test
        new File(BACKUP_FILE).delete();
        new File(RESTORE_FILE).delete();
    }

    @Test
    void testBackupArticles() {
        // Perform backup
        helpSystem.backupArticles(BACKUP_FILE);

        // Verify the backup file exists
        File backupFile = new File(BACKUP_FILE);
        assertTrue(backupFile.exists(), "Backup file should exist after backup operation");

        // Verify the content of the backup file
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(BACKUP_FILE))) {
            List<Article> backedUpArticles = (List<Article>) ois.readObject();
            assertEquals(2, backedUpArticles.size(), "Backup file should contain 2 articles");
            assertEquals("Test Article 1", backedUpArticles.get(0).getTitle(), "First article title should match");
            assertEquals("Test Article 2", backedUpArticles.get(1).getTitle(), "Second article title should match");
        } catch (IOException | ClassNotFoundException e) {
            fail("Exception occurred while verifying the backup file: " + e.getMessage());
        }
    }   
    
}

    