package application_phase2;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javafx.scene.control.TextInputDialog;
import java.util.Optional;
import application.UserAccessControl;
import application.User;

/**
 * The HelpSystem class manages a collection of Article objects and provides methods
 * to perform CRUD operations, backup and restore data, and search functionality.
 * This class interacts with a DatabaseHelper to persist data and also supports
 * in-memory operations on articles.
 *
 * @see Article
 */
public class HelpSystem {
    private List<Article> articles = new ArrayList<>();
    //define type of student group here
    private Map<String, List<String>> generalGroups = new HashMap<>(); // Group name -> List of usernames
    private Map<String, List<String>> specialGroups = new HashMap<>(); // Special Group name -> List of usernames
    private DatabaseHelper dbHelper;
    private UserAccessControl userAdminController;
    
    /**
     * Constructor for HelpSystem that initializes with UserAccessControl.
     * 
     * @param userAdminController The UserAccessControl instance for managing users
     * @throws SQLException if there's an error connecting to the database
     */
    public HelpSystem() throws SQLException {
        //this.userAdminController = userAdminController; // Assign the controller
        dbHelper = new DatabaseHelper();
        dbHelper.connectToDatabase();
        loadArticlesFromDatabase(); // Load all saved articles on startup
        generalGroups = new HashMap<>();
        specialGroups = new HashMap<>();
    }
    
    /**
     * Load all articles from the database on startup.
     */
    private void loadArticlesFromDatabase() {
        try {
            articles = dbHelper.loadAllArticles();
            System.out.println("Articles loaded from database: " + articles.size());
        } catch (SQLException e) {
            System.err.println("Error loading articles from database: " + e.getMessage());
        }
    }

    public void setUserAdminController(UserAccessControl userAdminController) {
        this.userAdminController = userAdminController;
        System.out.println("UserAccessControl assigned to HelpSystem.");
    }

    /**
     * Creates a new article with the specified details, adds it to the in-memory list,
     * assigns it to the specified groups, and saves it to the database.
     *
     * @param id              Unique identifier for the article
     * @param title           Title of the article
     * @param level           Expertise level for the article
     * @param shortDescription Brief description of the article
     * @param keywords        Keywords associated with the article
     * @param body            Body content of the article
     * @param references      References for the article
     * @param groups          List of groups to which the article belongs
     * @throws Exception if there's an error saving the article to the database
     */
    public void createArticle(long id, String title, String level, String shortDescription, String keywords, String body, String references, List<String> groups) throws Exception {
        Article newArticle = new Article(id, title, level, shortDescription, keywords, body, references, false);
        for (String group : groups) {
            newArticle.addGroup(group);
        }
        articles.add(newArticle);
        dbHelper.saveArticle(newArticle);  // Assuming db save method
        System.out.println("Article created successfully with groups: " + groups);
    }

    /**
     * Updates an existing article's details, updates its groups, and persists the changes to the database.
     *
     * @param id              ID of the article to be updated
     * @param title           New title for the article
     * @param level           New expertise level for the article
     * @param shortDescription New short description for the article
     * @param keywords        New keywords for the article
     * @param body            New body content for the article
     * @param references      New references for the article
     * @param groups          New groups to assign to the article
     * @throws SQLException if there's an error updating the article in the database
     */
    public void updateArticle(long id, String title, String level, String shortDescription, String keywords, String body, String references, List<String> groups) throws SQLException {
        Article article = findArticleById(id);
        if (article != null) {
            article.setTitle(title);
            article.setLevel(level);
            article.setShortDescription(shortDescription);
            article.setKeywords(keywords);
            article.setBody(body);
            article.setReferences(references);
            article.getGroups().clear();
            article.getGroups().addAll(groups);

            dbHelper.updateArticle(article); // Automatically save changes to the database
            System.out.println("Article updated and saved to database.");
        } else {
            System.out.println("Article not found.");
        }
    }
    
    /**
     * Deletes an article from the in-memory list. This method only removes the article
     * if it's present in the list.
     *
     * @param id ID of the article to delete
     * @return true if the article was found and deleted, false otherwise
     */
    public boolean deleteArticle(long id) {
        Article article = findArticleById(id);
        if (article != null) {
            articles.remove(article);
            return true; // Article was successfully deleted
        }
        return false; // Article was not found
    }

    /**
     * Lists all articles that belong to a specific group by displaying summaries of each.
     *
     * @param group The group name to filter articles by
     */
    public void listArticlesByGroup(String group) {
        articles.stream()
                .filter(a -> a.belongsToGroup(group))
                .forEach(Article::displaySummary);
    }

    /**
     * Backs up all articles to a specified file.
     *
     * @param filename The name of the file to back up articles to
     */
    public void backupArticles(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(articles);
            System.out.println("Backup successful to file: " + filename);
        } catch (IOException e) {
            System.out.println("Error during backup: " + e.getMessage());
        }
    }
    
    /**
     * Restores articles from a specified file, with an option to either overwrite
     * the current list of articles or merge with them.
     *
     * @param filename            The file to restore articles from
     * @param clearCurrentArticles Whether to clear the current list before restoring
     */
    public void restoreArticles(String filename, boolean clearCurrentArticles) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            List<Article> restoredArticles = (List<Article>) ois.readObject();

            if (clearCurrentArticles) {
                articles.clear();
            }

            for (Article article : restoredArticles) {
                if (articles.stream().noneMatch(a -> a.getId() == article.getId())) {
                    articles.add(article);
                }
            }
            System.out.println("Articles restored from file: " + filename);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error during restore: " + e.getMessage());
        }
    }

    /**
     * Searches for articles by a specified keyword and displays summaries of matching articles.
     *
     * @param keyword The keyword to search for
     */
    public void searchArticles(String keyword) {
        articles.stream()
                .filter(a -> a.getKeywords().contains(keyword))
                .forEach(Article::displaySummary);
    }

    /**
     * Finds an article by its unique ID.
     *
     * @param id The ID of the article to find
     * @return The article if found, otherwise null
     */
    public Article findArticleById(long id) {
        return articles.stream().filter(a -> a.getId() == id).findFirst().orElse(null);
    }

    /**
     * Returns all articles in the system.
     *
     * @return List of all articles
     */
    public List<Article> getAllArticles() {
        return articles; // Assuming articles is the list where articles are stored
    }

    /**
     * Gets a list of articles belonging to a specified group.
     *
     * @param groupName The name of the group to filter articles by
     * @return List of articles in the specified group
     */
    public List<Article> getArticlesByGroup(String groupName) {
        return articles.stream()
                .filter(article -> article.getGroups().contains(groupName))
                .collect(Collectors.toList());
    }

    /**
     * Backs up articles belonging to a specified group to a file. If no group is specified,
     * all articles are backed up.
     *
     * @param filename The file to back up articles to
     * @param group    The group name to filter articles by for backup
     */
    public void backupArticlesByGroup(String filename, String group) {
        List<Article> articlesToBackup;
        
        // Filter articles based on the specified group
        if (group == null || group.isEmpty()) {
            articlesToBackup = articles; // No group specified, backup all articles
        } else {
            articlesToBackup = articles.stream()
                                       .filter(article -> article.getGroups().contains(group))
                                       .collect(Collectors.toList());
        }
        
        // Proceed to backup
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(articlesToBackup); // Serialize and write the list of articles to the file
            System.out.println("Backup successful to file: " + filename);
        } catch (IOException e) {
            System.out.println("Error during backup: " + e.getMessage());
        }
    }

//	public void sendMessage(String string) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	public String getSearchRequests() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	
	//new implementation for phase 4
	public List<Article> searchArticles(String query, String level, String group) {
	    return articles.stream()
	        .filter(article -> 
	            (group.equals("All") || article.getGroups().contains(group)) &&
	            (level.equals("All") || article.getLevel().equalsIgnoreCase(level)) &&
	            (article.getTitle().toLowerCase().contains(query.toLowerCase()) ||
	             article.getKeywords().toLowerCase().contains(query.toLowerCase()) ||
	             article.getShortDescription().toLowerCase().contains(query.toLowerCase())))
	        .collect(Collectors.toList());
	}
	
	// Stores search queries
	private List<String> searchRequests = new ArrayList<>();

	// Appends a message to "helpMessages.txt"
	public void sendMessage(String message) {
	    try (FileWriter writer = new FileWriter("helpMessages.txt", true)) {
	        writer.write(message + "\n\n"); // Append message with a newline
	        System.out.println("Message successfully saved to helpMessages.txt");
	    } catch (IOException e) {
	        System.err.println("Error saving message: " + e.getMessage());
	    }
	}

	// Retrieves all search requests as a formatted string
	public String getSearchRequests() {
	    if (searchRequests.isEmpty()) {
	        return "No search requests made.";
	    }
	    return String.join(", ", searchRequests);
	}

	// Adds a new search query to the list
	public void addSearchRequest(String query) {
	    if (query != null && !query.trim().isEmpty()) {
	        searchRequests.add(query.trim());
	    }
	}
	
	// Retrieves search requests as a List
	public List<String> getSearchRequestsAsList() {
	    return new ArrayList<>(searchRequests);
	}
	
	// Retrieves all saved messages
	public List<String> getAllMessages() {
	    List<String> messages = new ArrayList<>();
	    File file = new File("helpMessages.txt");

	    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
	        String line;
	        StringBuilder message = new StringBuilder();
	        while ((line = reader.readLine()) != null) {
	            if (line.trim().isEmpty() && message.length() > 0) {
	                messages.add(message.toString().trim());
	                message.setLength(0); // Reset for the next message
	            } else {
	                message.append(line).append("\n");
	            }
	        }
	        if (message.length() > 0) {
	            messages.add(message.toString().trim()); // Add the last message if any
	        }
	    } catch (IOException e) {
	        System.err.println("Error reading messages: " + e.getMessage());
	    }

	    return messages;
	}

	// Allow deleting the help message
	public boolean deleteMessage(int index) {
	    File file = new File("helpMessages.txt");
	    List<String> messages = getAllMessages(); // Retrieve all messages
	    if (index < 1 || index > messages.size()) {
	        return false; // Index out of range
	    }

	    // Remove the message
	    messages.remove(index - 1);

	    // Write updated messages back to the file
	    try (FileWriter writer = new FileWriter(file, false)) { // Overwrite the file
	        for (String message : messages) {
	            writer.write(message + "\n\n");
	        }
	        return true;
	    } catch (IOException e) {
	        System.err.println("Error updating messages: " + e.getMessage());
	        return false;
	    }
	}

	public boolean addGeneralGroup(String groupName) {
	    if (!generalGroups.containsKey(groupName)) {
	        generalGroups.put(groupName, new ArrayList<>()); // Create a new empty group
	        return true; // Successfully added
	    }
	    return false; // Group already exists
	}

	public boolean addSpecialGroup(String groupName) {
	    if (!specialGroups.containsKey(groupName)) {
	        specialGroups.put(groupName, new ArrayList<>()); // Create a new empty group
	        return true; // Successfully added
	    }
	    return false; // Group already exists
	}

	// method to view groups
	public List<String> getGeneralGroups() {
	    return new ArrayList<>(generalGroups.keySet());
	}

	public List<String> getSpecialGroups() {
	    return new ArrayList<>(specialGroups.keySet());
	}
	
	public List<String> getAllGroups() {
	    List<String> allGroups = new ArrayList<>();
	    allGroups.addAll(generalGroups.keySet()); // Add all general group names
	    allGroups.addAll(specialGroups.keySet()); // Add all special group names
	    return allGroups;
	}

	// method to delete groups
	public boolean deleteGeneralGroup(String groupName) {
	    return generalGroups.remove(groupName) != null;
	}

	public boolean deleteSpecialGroup(String groupName) {
	    return specialGroups.remove(groupName) != null;
	}

	 public boolean addStudentToGroup(String username, String groupName) {
	        // Check if the group exists
	        if (!generalGroups.containsKey(groupName) && !specialGroups.containsKey(groupName)) {
	            System.out.println("Group does not exist.");
	            return false;
	        }

	        // Check if the user exists
	        if (userAdminController == null) {
	            System.out.println("UserAdminController is not initialized.");
	            return false;
	        }

	        User user = userAdminController.locateUser(username);
	        if (user == null) {
	            System.out.println("User does not exist.");
	            return false;
	        }

	        // Add the student to the group
	        if (generalGroups.containsKey(groupName)) {
	            generalGroups.get(groupName).add(username);
	        } else if (specialGroups.containsKey(groupName)) {
	            specialGroups.get(groupName).add(username);
	        } else {
	            System.out.println("Failed to add to group.");
	            return false;
	        }

	        System.out.println("Student added to group successfully.");
	        return true;
	    }

	public List<String> getStudentsInGroup(String groupName) {
	    if (generalGroups.containsKey(groupName)) {
	        return new ArrayList<>(generalGroups.get(groupName));
	    } else if (specialGroups.containsKey(groupName)) {
	        return new ArrayList<>(specialGroups.get(groupName));
	    } else {
	        return new ArrayList<>(); // Return an empty list if the group does not exist
	    }
	}

	public boolean removeStudentFromGroup(String username, String groupName) {
	    // Check if the group exists in generalGroups
	    if (generalGroups.containsKey(groupName)) {
	        List<String> students = generalGroups.get(groupName);
	        if (students.remove(username)) {
	            return true; // Student successfully removed from general group
	        }
	    }
	    // Check if the group exists in specialGroups
	    if (specialGroups.containsKey(groupName)) {
	        List<String> students = specialGroups.get(groupName);
	        if (students.remove(username)) {
	            return true; // Student successfully removed from special group
	        }
	    }
	    return false; // Student or group not found
	}

}
