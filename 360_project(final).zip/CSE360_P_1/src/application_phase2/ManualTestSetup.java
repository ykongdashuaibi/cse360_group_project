package application_phase2;
import application_phase2.Article;
import application_phase2.DatabaseHelper;
import application_phase2.HelpSystem;
import application.UserAccessControl;
import application.Role;
import application.User;
import application.AdminPage;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

//test 2
public class ManualTestSetup {
    public static void main(String[] args) throws Exception {
        HelpSystem helpSystem = new HelpSystem();

        // Preload articles
        helpSystem.createArticle(1L, "Test Article 1", "Beginner", "Description 1", "keyword1", "Body 1", "Reference 1", List.of("Group1"));
        helpSystem.createArticle(2L, "Test Article 2", "Intermediate", "Description 2", "keyword2", "Body 2", "Reference 2", List.of("Group2"));

        System.out.println("Setup complete. Launch the application to perform manual testing.");
    }
}
