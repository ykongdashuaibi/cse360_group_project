package application_phase2;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * The Article class represents an individual article with various attributes such as
 * title, level, description, keywords, body, and groups. This class supports categorization
 * through groups, and articles can be marked as encrypted if needed.
 *
 * <p>Each article is uniquely identified by an ID and can be categorized by its level,
 * such as Beginner, Intermediate, Advanced, or Expert.</p>
 *
 * <p>This class implements Serializable to allow articles to be serialized, enabling
 * backup and restoration processes within the system.</p>
 * 
 * @see Serializable
 */
public class Article implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private long id; // Unique identifier
    private String title;
    private String level; // Beginner, Intermediate, Advanced, Expert
    private String shortDescription; // Short description for quick viewing
    private String keywords;
    private String body;
    private String references;
    private Set<String> groups = new HashSet<>(); // Groups for categorizing
    private boolean isEncrypted;

    /**
     * Constructs an Article object with the specified attributes.
     * 
     * @param id               Unique identifier for the article
     * @param title            Title of the article
     * @param level            Difficulty level (e.g., Beginner, Intermediate, etc.)
     * @param shortDescription Brief description for the article
     * @param keywords         Keywords associated with the article
     * @param body             Main content of the article
     * @param references       References or citations related to the article
     * @param isEncrypted      Flag indicating if the article is encrypted
     */
    public Article(long id, String title, String level, String shortDescription, String keywords, String body, String references, boolean isEncrypted) {
        this.id = id;
        this.title = title;
        this.level = level;
        this.shortDescription = shortDescription;
        this.keywords = keywords;
        this.body = body;
        this.references = references;
        this.isEncrypted = isEncrypted;
    }


    // Getters and Setters

    /**
     * Returns the unique identifier of the article.
     * 
     * @return the article ID
     */
    public long getId() {
        return id;
    }

    /**
     * Returns the title of the article.
     * 
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the article.
     * 
     * @param title the new title of the article
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Returns the difficulty level of the article.
     * 
     * @return the level of the article
     */
    public String getLevel() {
        return level;
    }

    /**
     * Sets the difficulty level of the article.
     * 
     * @param level the new level of the article
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * Returns the short description of the article.
     * 
     * @return the short description
     */
    public String getShortDescription() {
        return shortDescription;
    }

    /**
     * Sets the short description of the article.
     * 
     * @param shortDescription the new short description of the article
     */
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    /**
     * Returns the keywords associated with the article.
     * 
     * @return the keywords
     */
    public String getKeywords() {
        return keywords;
    }

    /**
     * Sets the keywords associated with the article.
     * 
     * @param keywords the new keywords for the article
     */
    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    /**
     * Returns the main content of the article.
     * 
     * @return the body of the article
     */
    public String getBody() {
        return body;
    }

    /**
     * Sets the main content of the article.
     * 
     * @param body the new body content of the article
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * Returns the references or citations associated with the article.
     * 
     * @return the references of the article
     */
    public String getReferences() {
        return references;
    }

    /**
     * Sets the references or citations associated with the article.
     * 
     * @param references the new references for the article
     */
    public void setReferences(String references) {
        this.references = references;
    }

    /**
     * Returns the groups associated with this article.
     * 
     * @return a set of groups
     */
    public Set<String> getGroups() {
        return groups;
    }

    /**
     * Sets the groups for categorizing the article.
     * 
     * @param groups the new set of groups
     */
    public void setGroups(Set<String> groups) {
        this.groups = groups;
    }

    /**
     * Checks if the article is encrypted.
     * 
     * @return true if the article is encrypted, false otherwise
     */
    public boolean isEncrypted() {
        return isEncrypted;
    }

    /**
     * Sets the encryption status of the article.
     * 
     * @param encrypted true to mark the article as encrypted, false otherwise
     */
    public void setEncrypted(boolean encrypted) {
        isEncrypted = encrypted;
    }

    // Method to display article summary for easy viewing
    public void displaySummary() {
        System.out.println("ID: " + id + " | Title: " + title + " | Level: " + level);
        System.out.println("Short Description: " + shortDescription);
    }

    // Method to add a group to the article
    public void addGroup(String group) {
        groups.add(group);
    }

    // Method to check if the article belongs to a specific group
    public boolean belongsToGroup(String group) {
        return groups.contains(group);
    }
}
